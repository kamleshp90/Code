package mobile.android.pages;

import org.openqa.selenium.By;

import base.SetupInit;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class AppPage extends SetupInit {

	By btnAccept = By.id("android:id/button1");

	By btnSideMenu = By.xpath("//android.widget.ImageButton[@content-desc='Open drawer']");

	By trendingSearches = By.xpath("//*[text()='Trending searches']");

	By settings = By.xpath("//*[@text='Settings']");

	By premiumError = By.xpath("//*[@text='Theme']");

	By externalStorage = By.xpath("//*[@text='Privileges']");
	
	By help = By.xpath("//*[@text='Help & feedback']");
	
	By back =  By.xpath("//android.widget.ImageButton[@content-desc=\"Navigate up\"]"); 
	
	By theme = By.xpath("//*[@text='Theme']");
	
	By dark = By.xpath("//*[@text='Dark']");
	
	By documentation = By.xpath("//*[@text='Documentation']");
	
	By lightTheme = By.xpath("//*[@text='Light']");
	
	By aboutAutomate = By.xpath("//*[@text='About Automate']");
	
	By version = By.xpath("//*[@text='Version 1.32.6']");
	

	public AppPage(AndroidDriver<MobileElement> driver) {
		this.mobileDriver = driver;
	}

	public void scroll() {
		try {
			//scroll(externalStorage,premiumError);
			//scrollDown();
			scrollUp();
			//swipe(DIRECTION.UP);
			//swipe(DIRECTION.DOWN);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to scroll");
		}
	}
	
	

	public void accept() {
		try {
			tapByElement(btnAccept);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click");
		}
	}

	public void clickOnSideMenu() {
		try {
			clickOnElement(btnSideMenu);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click");
		}
	}

	public void clickOnSettings() {
		try {
			clickOnElement(settings);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click");
		}
	}
	
	public void clickOnHelp() {
		try {
			clickOnElement(help);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click on Help");
		}
	}
	
	public void clickOnBack() {
		try {
			clickOnElement(back);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click on back");
		}
	}
	
	public void clickOnTheme() {
		try {
			clickOnElement(theme);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click on theme");
		}
	}
	
	public void clickOnDark() {
		try {
			clickOnElement(dark);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click on dark");
		}
	}
	
	public String getDocumentationText() {
		try {
			return getElementText(documentation);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to get Documentation Text");
		}
	}
	
	public String getDarkText() {
		try {
			return getElementText(dark);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to get Dark Text");
		}
	}
	
	public void scollTillAboutAutomate() {
		boolean found = false;
		while(!found) {
			
			try {				
				getMobileDriver().findElement(aboutAutomate);
				found = true;
				
			}catch(Exception e) {				
				scrollUp();
			}			
		}
	}
	
	public void clickOnAboutAutomate() {
		try {
			clickOnElement(aboutAutomate);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to click on About Automate");
		}
	}
	
	public String getVersionText() {
		try {
			return getElementText(version);
		} catch (Exception e) {
			throw new RuntimeException("Unbale to get Version Text");
		}
	}

}
package mobile.android.testCases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.TestListener;

import base.SetupInit;
import bsh.BshClassManager.Listener;
import createobject.CreateObject;

@Listeners(listeners.TestListener.class)
public class AppTestcase extends SetupInit {

	Map<Object, Object> data;
	protected CreateObject co;

	@SuppressWarnings("unchecked")
	@BeforeMethod
	public void InitializeMethod() {
		co = new CreateObject(getMobileDriver());
	}

	@Test(enabled = false, priority = 1)
	public void test() throws Exception {
		try {
			co.aPage.accept();
			co.aPage.clickOnSideMenu();						
			co.aPage.swipe(DIRECTION.RIGHT);
			co.aPage.swipe(DIRECTION.LEFT);
			co.aPage.clickOnSettings();
		    co.aPage.scroll();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * 1.Launch an app using your code
	 * 2.Open side menu in app > Go to help > Verify context
	 * 3.Go to settings > Theme Change Theme to  Dark/Light > Verify
	 * 4.Scroll till the end and verify version in About Automate option
	 */
	@Test(enabled = true)
	public void assignment1_Day4() throws Exception {
		try {
			co.aPage.accept();
			co.aPage.clickOnSideMenu();
			co.aPage.clickOnHelp();
			Assert.assertEquals("Documentation", co.aPage.getDocumentationText());
			
			co.aPage.clickOnBack();
			co.aPage.clickOnSideMenu();
			co.aPage.clickOnSettings();
			co.aPage.clickOnTheme();
			co.aPage.clickOnDark();
			Thread.sleep(3000);
			Assert.assertEquals("Dark", co.aPage.getDarkText());
			
			co.aPage.scollTillAboutAutomate();
//			Thread.sleep(1000);
			co.aPage.clickOnAboutAutomate();
			Thread.sleep(3000);
			Assert.assertEquals("Version 1.32.6", co.aPage.getVersionText());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	@Test(enabled = true)
	public void testFail() {
		Assert.assertEquals(true, false);
	}
}

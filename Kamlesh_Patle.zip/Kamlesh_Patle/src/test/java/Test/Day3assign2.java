package Test;

import static org.hamcrest.Matchers.equalTo;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.hamcrest.Matchers;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

import java.io.File;
import java.io.IOException;
import java.util.Map;

public class Day3assign2 
{
	@Test
	public void requestPosts1()
	{
		given().
			contentType(ContentType.JSON).
		when().
			get("http://localhost:3000/posts/1").
		then().
			assertThat().
			statusCode(200).
			assertThat().
			body("author", Matchers.equalTo("Sachin"));
	}
	
	@Test
	public void requestComments2()
	{
		given().
			contentType(ContentType.JSON).
		when().
			get("http://localhost:3000/comments/2").
		then().
			assertThat().
			statusCode(200).
			assertThat().
			body("id",Matchers.equalTo(2));
	}
	
	@Test
	public void requestPostsId2()
	{
		given().
		contentType(ContentType.JSON).
		pathParam("resourceCode","posts").and().pathParam("id","1").
	when().
		get("http://localhost:3000/{resourceCode}/{id}").
	then().
		assertThat().
		statusCode(200).
		assertThat().
		body("author", Matchers.equalTo("Sachin"));
	}
	
	@DataProvider
	public static Object[][] requestPostsResourceAndIds()
	{
		return new Object[][] {{"posts","1","Sachin"},
								{"posts","4","Anirudha"},
								};
	}
	
//	{"comments","2","some comment globant 2"},
//	{"comments","4","some comment globant 4"}
	
	@Test(dataProvider="requestPostsResourceAndIds")
	public void requestPostsId(String resource,String id, String response)
	{
		given().
			contentType(ContentType.JSON).
			pathParam("resource", resource).
			and().
			pathParam("id", id).
		when().get("http://localhost:3000/{resource}/{id}").
		then().
			assertThat(). 
			body("author",Matchers.equalTo(response));
	}
	
	
	@DataProvider
	public static Object[][] requestCommentsResourceAndId()
	{
		return new Object[][] {{"comments",2,"some comment globant 2"},
							   {"comments",4,"some comment globant 4"}};
	}
	
	@Test(dataProvider="requestCommentsResourceAndId")
	public void requestCommentsAndId(String resource,int id, String response)
	{
		given().
		contentType(ContentType.JSON).
		pathParam("resource", resource).
		and().
		pathParam("id", id).
	when().get("http://localhost:3000/{resource}/{id}").
	then().
		assertThat(). 
		body("body",Matchers.equalTo(response));
	}

	
	
// Data provider(Excel)
	
	@Test(dataProvider = "getApiEndPointData", dataProviderClass = Utility.ExcelUtility.class,testName="verifyExcelDataProvider_BookTest")
    public void verifyExcelDataProvider_BookTest(String methodName, String serviceEndpoint, Map<String,String> headerMap, Map<String,String> queryParamMap,Map<String,Object> pathParamMap,int statusCode,String responseMessage, String assertMessage) {

    	given().
    		pathParams(pathParamMap).
        when().
            get(serviceEndpoint).
        then().
            assertThat().
            statusCode(statusCode).
            body(assertMessage, equalTo(responseMessage));
    }
	

	
	

}



package Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.hamcrest.MatcherAssert.assertThat;
import org.hamcrest.Matchers;
import org.testng.asserts.*;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pojo_models.Friends;
import pojo_models.FriendsWithLombok;

import static io.restassured.RestAssured.*;



public class DAY5assign1 
{
	private static final FriendsWithLombok FriendWithLombok = null;
	private static RequestSpecification requestSpec;	
	private static  SoftAssert asert;
	
	@BeforeClass
	public static void setRquestSpec() {
		requestSpec=new RequestSpecBuilder().setBaseUri("http://localhost:3000").setContentType(ContentType.JSON).build();
		asert=new SoftAssert();
	}
	
	//without Lambok
	@Test
	public void addFriendsWithLib() {
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("firstname", "Tom");
		map.put("lastname", "Linden");
		map.put("id", 1);
		map.put("age", 30);
		
		Response response= given().log().all().spec(requestSpec).body(map).post("friends");
		response.prettyPrint();
		
		JsonPath jsonpath=response.jsonPath();
		assertThat(jsonpath.getString("firstname"),Matchers.equalTo("Tom"));
		assertThat(response.statusCode(),Matchers.equalTo(201));
		assertThat(response.as(Friends.class).getId(), Matchers.equalTo(1));		
	}
	
	//without Lambok
	@Test
	public void addNewFriendWithSameId()
	{
		Response response=given().spec(requestSpec).pathParam("id", 1).
		when().
			get("friends/{id}");
		JsonPath jsonpath=response.jsonPath();
		
		Map<String,Object> friendMap=new HashMap<String,Object>();
		friendMap.put("firstname", "Kevin");
		friendMap.put("lastname", "zender");
		friendMap.put("id", jsonpath.getString("id"));
		friendMap.put("age", 35);
		
		given().
			log().all().spec(requestSpec).body(friendMap).
		when().
			post("friends").
		then().
			assertThat().statusCode(500);
	}
	
	@Test
	public void verifyFriends()
	{
		List<Friends> friend=Arrays.asList(given().log().all().spec(requestSpec).get("friends").as(Friends[].class));
		System.out.println(friend);
		
		for(int i=0;i<friend.size();i++)
		{
			if(friend.get(i).getId()==1)
			{
				asert.assertEquals(friend.get(i).getFirstname(), "Tom");
				asert.assertEquals(friend.get(i).getLastname(), "Linden");
				asert.assertEquals(friend.get(i).getAge(), 30);
				break;
			}
		}
		asert.assertAll();
	}
	
	@Test
	public void addFriendsWithLambok()
	{
//		FriendsWithLombok friend=FriendsWithLombok.builder()
//				.firstname("Ankit")
//				.lastname("Rai")
//				.id(5)
//				.age(27)
//				.build();
		
//		Response response=given().log().all().spec(requestSpec).body(friend).post("friends");
//		response.prettyPrint();
//		assertThat(response.statusCode(),Matchers.equalTo(201));
//		assertThat(response.as(Friends.class).getAge(),Matchers.equalTo(27));
		
	}
	
	@Test
	public void verifyFriendsWithLambok()
	{
//		List<FriendsWithLombok> friend=Arrays.asList(given().log().all().spec(requestSpec).get("friends").as(FriendsWithLombok[].class));
//		
//		for(int i=0;i<friend.size();i++)
//		{
//			if(friend.get(i).getId()==1)
//			{
//				asert.assertEquals(friend.get(i).getFirstname(), "Tom");
//				asert.assertEquals(friend.get(i).getLastname(), "Linden");
//				asert.assertEquals(friend.get(i).getAge(), 30);
//			}
//		}
		
		
		
		
	}
	
	
	

}

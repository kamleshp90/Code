package Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;

import java.io.File;
import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;


public class Day3assign1 
{
	
	

	@Test
	public void verifyFriendsAddedSimple_Test()
	{
		JSONObject friendsObject=new JSONObject();
		friendsObject.put("firstname","Arif");
		friendsObject.put("lastname","Mulla");
		friendsObject.put("id","77");
		friendsObject.put("age","25");		
		
		given().
			contentType(ContentType.JSON).
			body(friendsObject.toString()).
		when().
			post("http://localhost:3000/friends").
		then().
			assertThat().
			statusCode(201);
		
		given().
			contentType(ContentType.JSON).
		when().
			get("http://localhost:3000/friends"). 
		then(). 
			assertThat().
			body("firstname", hasItem("Arif"));
	}

	@Test
	public void verifyFriendsAddedMedium_Test()
	{
		JSONObject friendsObject=new JSONObject();
		JSONObject addressObject=new JSONObject();
		addressObject.put("streetName", "Blue ridge");
		addressObject.put("houseNo", "7");
		friendsObject.put("firstname", "Rahul");
		friendsObject.put("lastname", "Lanjevar");
		friendsObject.put("address", addressObject);
		friendsObject.put("id", "2000");
		friendsObject.put("age", "25");
		
		given().
			contentType(ContentType.JSON).
			body(friendsObject.toString()).
		when().
			post("http://localhost:3000/friends").
		then().
			assertThat().
			statusCode(201);
		
			get("http://localhost:3000/friends").
		then().
			assertThat().
			body("address.'streetName'", hasItem("Blue ridge"));
		
	}


	@Test
	public void verifyFriendsAddedComplex_Test()
	{
		JSONObject friendsObject = new JSONObject();
		JSONObject primeryAdd=new JSONObject();
		primeryAdd.put("streetName", "satara road");
		primeryAdd.put("houseNo", "2111");
		JSONObject secondaryAdd=new JSONObject();
		secondaryAdd.put("streetName", "aundh road");
		secondaryAdd.put("houseNo", "4121");
		JSONArray address=new JSONArray();
		address.put(0, primeryAdd);
		address.put(1, secondaryAdd);
		friendsObject.put("firstname", "Krunal");
		friendsObject.put("lastname", "Kene");
		friendsObject.put("address", address);
		friendsObject.put("id", "99");
		friendsObject.put("age", "25");
		
		given().
			contentType(ContentType.JSON).
			body(friendsObject.toString()).
			post("http://localhost:3000/friends");
		
			get("http://localhost:3000/friends").
		then().
			assertThat().
			body("firstname", hasItem("Krunal"));
	}
	
	@Test
	public void verifyPostsAddedSimpleJsonFile_Test()
	{
		File fileSimple=new File("./src/test/resources/postdb.json");
		given().
			contentType(ContentType.JSON).
			body(fileSimple).
		when().
			post("http://localhost:3000/posts");
		
		given().
			contentType(ContentType.JSON).
			pathParam("id", "5").
		when().
			get("http://localhost:3000/posts/{id}").
		then().
			assertThat().body("title",equalTo( "API-Automation practice title 5"));
	}
	
	@Test
	public void verifyPostsAddedMediumJsonFile_Test()
	{
		File fileMedium=new File("./src/test/resources/postdb6.json");
		given().
			contentType(ContentType.JSON).
			body(fileMedium).log().body().
		when().
			post("http://localhost:3000/posts");
		
		given().
		contentType(ContentType.JSON).
		pathParam("id", "6").
	when().
		get("http://localhost:3000/posts/{id}").
	then().
		assertThat().body("author.'autherName'",Matchers.equalTo("Anirudha"));
	}
	
	@Test
	public void verifyPostsAddedComplexJsonFile_Test()
	{
		File fileComplex=new File("./src/test/resources/postdb7.json");
		given().
			contentType(ContentType.JSON).
			body(fileComplex).
		when().
			post("http://localhost:3000/posts");
		
		given().
			contentType(ContentType.JSON).
			pathParam("id", "7").
			get("http://localhost:3000/posts/{id}").
		then().
			assertThat().
			body("author[0].'creditName'", Matchers.equalTo("Snehal"));
		

	}	
	
}

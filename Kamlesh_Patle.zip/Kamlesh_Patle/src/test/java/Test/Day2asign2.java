package Test;

import static org.hamcrest.Matchers.equalTo;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class Day2asign2 
{
	@Test(enabled=false)
	public void requestBooking_checkStatusCode_expectHttp200()
	{
		given().
			pathParam("id", "610").
		when().
			get("https://restful-booker.herokuapp.com/booking/{id}").
		then(). 
			assertThat(). 
			statusCode(200);
	}
	
	@Test(enabled=false)
	public void requestBooking_logRequestAndResponseDetails()
	{
		given().
			params("id","610").
			log().all().
		when().
			get("https://restful-booker.herokuapp.com/booking/{id}"). 
		then(). 
			log().body();
	}
	
	@Test(enabled=false)
	public void requestBooking_checkItemValuesInResponseBody()
	{
		Response response=given().
			pathParam("id","610").
		when().
			get("https://restful-booker.herokuapp.com/booking/{id}");	
		JsonPath jsonpath=response.jsonPath();
		String firstName= jsonpath.getString("firstname");
		String lastName= jsonpath.getString("lastname");
		String totalPrice= jsonpath.getString("totalprice");
		System.out.println("firstname= "+firstName);
		System.out.println("lastname= "+lastName);
		System.out.println("totalprice= "+totalPrice);
	}
	
	@Test(enabled=false)
	public void requestBooking_verifyItemValuesInResponseBody()
	{
		given().
			pathParam("id","610"). 
		when().
			get("https://restful-booker.herokuapp.com/booking/{id}").
		
		then().
			body("firstname", equalTo("Omela3")).
			and(). 
			body("lastname", equalTo("Tester3")).
			and().
			body("totalprice", equalTo(1));
	}
	
	@Test
	public void getUserData()
	{
		given()
			.contentType(ContentType.JSON)
			.log().all()
		.when()
			.get("https://gorest.co.in/public/v2/users")
		.then()
			.assertThat()
			.body("id",Matchers.hasItem(2174))
			.assertThat().statusCode(200);
	}
}





















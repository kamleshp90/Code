package pojo_models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString


@JsonIgnoreProperties(ignoreUnknown = true)
public class Report {
	public Reporter_details getReporter_details() {
		return reporter_details;
	}
	public void setReporter_details(Reporter_details reporter_details) {
		this.reporter_details = reporter_details;
	}
	public Child_details getChild_details() {
		return child_details;
	}
	public void setChild_details(Child_details child_details) {
		this.child_details = child_details;
	}
	public Incident_details getIncident_details() {
		return incident_details;
	}
	public void setIncident_details(Incident_details incident_details) {
		this.incident_details = incident_details;
	}
	private Reporter_details reporter_details;
	private Child_details child_details;
	private Incident_details incident_details;

}

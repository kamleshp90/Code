package modules;

import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.Report;
import pojo_models.UserInfoWithLombok;

public class VerifyReportFunctionality {
	
	public ResponseOptions<Response> verifyAddReportFunctionality(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyAddReportFunctionalityWithStringBody(String methodName, String serviceEndpoint, String payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyGetReportFunctionality(String methodName, String serviceEndpoint, String token , Map<String , String> pathParamsMap){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParams(methodName, serviceEndpoint , pathParamsMap);
	}

	
	public ResponseOptions<Response> verifyDeleteReportFunctionality(String methodName, String serviceEndpoint, String token , String userId , String content){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		Map<String, String> pathParamsMap=new  LinkedHashMap<String, String>();
		pathParamsMap.put("content", content);
		pathParamsMap.put("userId", userId);
		return restAssuredEngine.executeWithPathParams(methodName, serviceEndpoint , pathParamsMap);
	}

	
	public Map<String, String> getReportPathParam(String content)
	{
		Map<String, String> hmap=new  LinkedHashMap<String, String>();
		hmap.put("content", content);
		return hmap;
	}
	
	public Report getReportDetails(String payload)
	{
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			Report reportPayload = mapper.readValue(payload, Report.class);
			return reportPayload;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

}

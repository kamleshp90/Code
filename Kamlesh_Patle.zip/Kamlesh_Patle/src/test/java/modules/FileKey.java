package modules;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class FileKey {
	
	public ResponseOptions<Response> getFileKey(String methodName, String serviceEndpoint, String token, String path){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		File file = new File(path);
		System.out.println("********************---endpoint---**************");
		System.out.println(serviceEndpoint);
		System.out.println("********************---endpoint---**************");
		return restAssuredEngine.executeWithFormBody(methodName, serviceEndpoint, file);
	}
	
	public ResponseOptions<Response> getFileKey(String methodName, String serviceEndpoint, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		File file = null;
		System.out.println("********************---endpoint---**************");
		System.out.println(serviceEndpoint);
		System.out.println("********************---endpoint---**************");
		return restAssuredEngine.executeWithoutFormBody(methodName,file, serviceEndpoint);
	}
	
	public ResponseOptions<Response> fileDownload(String methodName, String serviceEndpoint, String token, String file_key){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		Map<String, String> hmap=new  LinkedHashMap<String, String>();
		hmap.put("file_key", file_key);
		return restAssuredEngine.executeWithPathParams(methodName, serviceEndpoint, hmap);
	}
	

}

package modules;

import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.UserInfoWithLombok;
import Utility.RestAssuredEngine;

public class UserSignUp {
	
	public ResponseOptions<Response> verifyEmailId(String methodName, String serviceEndpoint, String payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyValidOtp(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	public UserInfoWithLombok getUserInfoPayload(String payload)
	{
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			UserInfoWithLombok userInfo = mapper.readValue(payload, UserInfoWithLombok.class);
			return userInfo;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
//	String s="{\n"
//			+ "    \"email_id\":\"Shad.Schmidt@hotmail.com\",\n"
//			+ "    \"full_name\":\"Kamlesh Patle\",\n"
//			+ "    \"phone_number\":\"9876543211\",\n"
//			+ "    \"password\":\"fmcFMC\",\n"
//			+ "    \"otp\":\"\"\n"
//			+ "}";

}

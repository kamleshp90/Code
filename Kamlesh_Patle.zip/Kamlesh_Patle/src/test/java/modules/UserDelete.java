package modules;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class UserDelete {
	
	
	public ResponseOptions<Response> deleteUser(String methodName, String serviceEndpoint, String payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, payload);
	}

}

package Java_basics;

public class Superclass {
	
	public Superclass(int a, int b)
	{
		
	}
	
	
	public void Method()
	{
		System.out.println("methd in super class");
	}
	
	 static int x = 10;

	public static void main(String[] args) {
		String s="mississippi";
		String[] sa=s.split("");
		for(String c:sa)
		{
			System.out.println(c);
		}

	}

}

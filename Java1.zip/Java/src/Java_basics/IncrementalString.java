package Java_basics;

public class IncrementalString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Selenium";
		
		for(int i=0;i<s.length();i++)
		{
			for(int j=0;j<s.length()-i;j++)
			{
				System.out.print(s.charAt(j));
			}
			System.out.println();
		}

	}

}

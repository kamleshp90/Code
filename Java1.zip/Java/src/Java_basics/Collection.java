package Java_basics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Integer> hmap=new HashMap<String,Integer>();
		
		hmap.put("Kalishka", 1);
		hmap.put("Kishika", 2);
		hmap.put("Nisika", 4);
		hmap.put("Diksha", 3);
		hmap.put("Aalisha", 3);
		
//		for(Map.Entry<String,Integer> e : hmap.entrySet())
//		{
//			System.out.println(e.getKey()+" : "+e.getValue());
//			
//			
//		}
		
		

		
		
		ArrayList<Integer> s=new ArrayList<Integer>(Arrays.asList(2,4,6,8,5,3,9,15));
		
		s.stream().map(e->e*2).forEach(e->System.out.println(e));
		
		
		
	
		
		
		
		

	}

}

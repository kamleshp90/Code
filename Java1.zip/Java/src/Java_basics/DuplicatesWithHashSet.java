package Java_basics;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicatesWithHashSet {

	public static void main(String[] args) {
		
		
		//Occurence of character
		
//		String word="World is awesome or not ";
//		int count=0;
//		Set<Character> dword=new LinkedHashSet();
//		char [] cArr=word.toLowerCase().toCharArray();
//		for(Character e:cArr)
//		{
//			for(int i=0;i<cArr.length;i++)
//			{
//				if(e==cArr[i])
//				{
//					count++;					
//				}
//				if(count>1 && e!=' ' && i==cArr.length-1 && !dword.contains(e))
//				{					
//					dword.add(e);
//					System.out.println("count of "+e+ " : "+count);				
//				}
//				
//			}
//			count=0;
//			
//			
//		}
		
		// if two strings are anagrams of each other? *******************************************************
//		String s1="army";
//		String s2="marry";
//		char [] cs1=s1.toCharArray();
//		char [] cs2=s2.toCharArray();
//		Arrays.sort(cs1);
//		Arrays.sort(cs2);
//		if(Arrays.equals(cs1, cs2))
//			{
//				System.out.println("Anagrams");
//			}
//		else
//		{
//			System.out.println("Not anagrams");
//		}
		
		
		// reverse string at given position *******************************************************
//		String inputString="Arise! Awake! and stop not until the goal is reached";
//		String [] inputStringArray=inputString.split(" ");
//		StringBuilder builder=new StringBuilder();
//		for(int i=0;i<inputStringArray.length;i++)
//		{
//			for(int j=inputStringArray[i].length()-1;j>=0;j--)
//			{
//				builder.append(inputStringArray[i].charAt(j));
//			}
//			builder.append(" ");
//		}
//		
//		System.out.println(builder.toString());
		
		// Pallindrome *******************************************************
//		String s1="toyot";
//		String s2="toyot";
//		String result="Pallindrome";
//		
//		if(s1.length()!=s2.length())
//		{
//			System.out.println("not a Pallindrome");
//		}
//		
//		for(int i=0;i<s1.length();i++)
//		{
//			if(s1.charAt(i)!=s2.charAt(s1.length()-(i+1)))
//			{
//				result="not a Pallindrome";
//				break;
//			}
//		}
//		
//		System.out.println("Strings are "+result);
			
		// check if a String contains only digits? *******************************************************
		
//		String s="123";
//		
//				// first way
//		if(s.matches("\\d+"))
//		{
//			System.out.println("Only digits");
//		}
//				// second way
//		try
//		{
//		Integer.valueOf(s);
//		System.out.println("digit string");
//		}
//		catch(Exception e)
//		{
//			System.out.println("Non digit string");
//		}
//		finally
//		{
//			System.out.println("********test done*********");
//		}
		
		// remove all digits *******************************************************
		
//		String s="123hv24v1v24242h098k";
//		s=s.replaceAll("[0-9]", "");
//		s=s.replaceAll("[^0-9]", "");
//		System.out.println(s);
		
		// Pallindrome no. *******************************************************
		
//		int n= 153;
//		int d=n;
//		int s=0;
//		int r=0;
//		for(int i=0;n>0;n=n/10)
//		{
//			r=n%10;
//			s=s+(r*r*r);
//		
//		}
//		System.out.println(s);
		
		// Largest no. in an array *******************************************************
		
		int [] arr= {34,5,12,101,78,43,99};
		int n=0;
		for(int i:arr)
		{
			if(n<i)
			{
				n=i;
			}
		}
		
		System.out.println(n);
		
		
	}

}

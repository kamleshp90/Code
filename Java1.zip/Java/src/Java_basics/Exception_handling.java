package Java_basics;

public class Exception_handling {
	
	
	public static void throwException() throws Exception
	{
//		ArrayIndexOutOfBoundsException
//        ae
//        = new ArrayIndexOutOfBoundsException();	
		Exception eoi=new Exception();
//		eoi.initCause(ae);
		
		throw eoi;
	}

	public static void main(String[] args) {
		
		try
		{
			System.out.println(10/0);
		}
		catch(ArithmeticException e )
		{
//			e.printStackTrace();
			System.out.println(e);
			System.out.println(e.toString());
			System.out.println(22/0);
		}

		

	}

}

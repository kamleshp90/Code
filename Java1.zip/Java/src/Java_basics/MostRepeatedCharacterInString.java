package Java_basics;

import java.util.HashMap;
import java.util.Map;

public class MostRepeatedCharacterInString {

	public static void main(String[] args) {
		
		Map<Character, Integer> hm=new HashMap<>();
		String s="mississippipp";
		int count=1;
		int maxCout=0;
		char c=' ';
		String temp="";
		for(int i=0;i<s.length()-1;i++)
		{
			if ( temp.indexOf(s.charAt(i))==-1) temp=temp+s.charAt(i);
			else continue;
			for(int j=i+1;j<s.length();j++)
			{
				
				if(s.charAt(i)==s.charAt(j))
				{
					count++;
				}
				
			}
			if(count>=maxCout)
				{
				c=s.charAt(i);
				maxCout=count;
				hm.put(c, count);
				
				}
			count=1;
		}
		for(Map.Entry<Character, Integer> e:hm.entrySet())
		{
			if(e.getValue()==maxCout)
			{
				System.out.println(e.getKey()+"="+e.getValue());
			}
		}

	}

}

package Java_basics;

public class Subclass extends Superclass {

	public Subclass()
	{
		super(3,5);		
	}
	
	public Subclass(int a,int b)
	{
		super(a, b);
		
	}
	
	public void Method()
	{
		System.out.println("methd in sub class");
	} 
	
	
	
	public static void main(String[] args) {
//		Subclass sub=new Subclass();
//		sub.Method();
//		Superclass sup=new Superclass(3,6);
//		sup.Method();
		
		
		String s="selenium";
		for(int i=0;i<s.length();i++)
		{
			for(int j=0;j<=i;j++)
				{
					System.out.print(s.charAt(j));
				}
			System.out.println();
		}
		
		for(int i=s.length()-1;i>=0;i--)
		{
			for(int j=0;j<=i;j++)
				{
					System.out.print(s.charAt(j));
				}
			System.out.println();
		}

	}

}

package Interface;



@FunctionalInterface
public interface MyInterface {

	public String print(String name);
	public default void Hello()
	{
		System.out.println("Hello");
	}
	public static void pStatic()
	{
		System.out.println("Static");
	}
	
}

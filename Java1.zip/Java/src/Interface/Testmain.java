package Interface;

public class Testmain {

	public static void main(String[] args) {
		
		MyInterface mi=(n)-> n.toUpperCase();
		
		execute(mi);
		execute((n)-> n.toUpperCase());
		

	}
	
	public static void execute(MyInterface m)
	{
		String str=m.print("WelCome");
		System.out.println(str);
		
	}

}

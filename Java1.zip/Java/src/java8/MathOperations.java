package java8;

public interface MathOperations {
	
	public int operate(int a , int b);

}

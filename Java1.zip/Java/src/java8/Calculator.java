package java8;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Calculator {
	public static void main(String[] args) {

		MathOperations add = (a, b) -> a + b;
		MathOperations sub = (a, b) -> a - b;
		MathOperations devide = (a, b) -> a / b;
		MathOperations multiply = (a, b) -> a * b;
//		
		int onScreenNumber = 0;
		onScreenNumber = calculate(onScreenNumber, add, 5);
		onScreenNumber = calculate(onScreenNumber, sub, 3);
		onScreenNumber = calculate(onScreenNumber, multiply, 64);
		onScreenNumber = calculate(onScreenNumber, devide, 8);

		System.out.println(onScreenNumber);

		onScreenNumber = 0;
		onScreenNumber = calculate(onScreenNumber, "add", 5);
		onScreenNumber = calculate(onScreenNumber, "sub", 3);
		onScreenNumber = calculate(onScreenNumber, "multiply", 64);
		onScreenNumber = calculate(onScreenNumber, "devide", 8);

		System.out.println(onScreenNumber);

		System.out.println(calculate("5 - 3 * 64 / 8"));

	}

//	private static Map<String , String> operator=new HashMap<>();
	private static final Map<String, BiFunction<Integer, Integer, Integer>> MAP = new HashMap<>();

	static {
		MAP.put("+", (a, b) -> a + b);
		MAP.put("-", (a, b) -> a - b);
		MAP.put("/", (a, b) -> a / b);
		MAP.put("*", (a, b) -> a * b);
	}

	public static int calculate(String expression) {
		String[] ele = expression.split(" ");
		int onScreenNumber = Integer.parseInt(ele[0]);
		for (int i = 1; i < ele.length - 1; i = i + 2) {
			onScreenNumber = MAP.get(ele[i]).apply(onScreenNumber, Integer.parseInt(ele[i + 1]));
		}
		return onScreenNumber;
	}

	private static int calculate(int onScreenNumber, MathOperations mathOperations, int enteredNumber) {

		return mathOperations.operate(onScreenNumber, enteredNumber);
	}

	private static int calculate(int onScreenNumber, String mathOperations, int enteredNumber) {
		switch (mathOperations) {
		case "add":
			return onScreenNumber + enteredNumber;

		case "sub":
			return onScreenNumber - enteredNumber;

		case "devide":
			return onScreenNumber / enteredNumber;

		case "multiply":
			return onScreenNumber * enteredNumber;

		default:
			System.out.println("invalid input");
			return 0;
		}
	}

//	public static int add(int a, int b)
//	{
//		MathOperations mo=(c,d)-> c+d;
//		return mo.operate(a, b);
//	}
//	
//	public int sub(int a , int b)
//	{
//		MathOperations mo=(c,d)->c-d;
//		return mo.operate(a, b);
//	}
//	
//	public int multiply(int a , int b)
//	{
//		MathOperations mo=(c,d)->c*d;
//		return mo.operate(a, b);
//	}
//	public int devide(int a , int b)
//	{
//		MathOperations mo=(c,d)->c/d;
//		return mo.operate(a, b);
//	}

}

package PropertiesFileReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileWriter {

	public static File file;
	
	void writeConfigFile(Properties p)
	{
		FileOutputStream fos=null;
		try {
			 fos = new FileOutputStream(file,true);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			p.store(fos, "");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public static void main(String[] args) {
	
		file=new File("/Users/kamlesh.patle/eclipse-workspace/Java/TestData.properties");
		Properties p=new Properties();
		p.setProperty("name", "jayant");
		ConfigFileWriter cfw=new ConfigFileWriter();
		cfw.writeConfigFile(p);		
	}

}

package PropertiesFileReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationFileReader {

	public static void main(String[] args) throws IOException {
		
		Properties props=new Properties();
		FileReader reader=new FileReader("/Users/kamlesh.patle/eclipse-workspace/Java/TestData.properties");
		props.load(reader);
		System.out.println(props.getProperty("name"));
		
	}

}

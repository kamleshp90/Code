package LeetCode;

public class Plu_One_66 {

	public static void main(String[] args) {
//		int[] digits= {9,9,9,9};
//		int[] digits= {4,1,2,3};
//		int[] digits= {9};
		int[] digits= {1,2,3};
		int[] outputArr=plusOne(digits);
		for(int i:outputArr)
		{
			System.out.println(i);
		}
	}

	private static int[] plusOne(int[] digits) {
		for(int i=digits.length-1;i>=0;i--)
		{
			if(digits[i]+1==10)
			{
				if(i!=0) digits[i]=0;
				else 
				{
					int[] arr=new int[digits.length+1];
					for(int j=arr.length-1;j>1;j--)
					{
						arr[j]=digits[j-1];
					}
					arr[1]=0;
					arr[0]=1;
					return arr;
				}				
			}
			else
			{
				digits[i]++;
				return digits;
			}			
		}
		return null;
	}
}

package LeetCode;

public class MaximumSubarray_53 {

	public static void main(String[] args) {
		
		int[] nums= {0,-1,-2};
		int s=maxSubArray(nums);
		System.out.println(s);
	}

	private static int maxSubArray(int[] nums) {
		int csum=0;
		int maxsum=nums[0];		
		for(int i=0;i<nums.length;i++)
		{
			csum=csum+nums[i];
			if(csum>maxsum) maxsum=csum;
			if(csum<0) csum=0;
		}
		
		return maxsum;	
	}

}

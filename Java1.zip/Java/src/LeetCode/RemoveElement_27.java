package LeetCode;

public class RemoveElement_27 {

	public static void main(String[] args) {
//		int[] nums = {0,1,2,2,3,0,4,2}; int  val = 2;
//		int[] nums = {3,2,2,3}; int  val = 3;
//		int[] nums = {0,1,2,2,3,0,4,2}; int  val = 2;
//		int[] nums = {2}; int  val = 2;
//		int[] nums = {3,3}; int  val = 3;
		int[] nums = {4,5}; int  val = 5;
				
		System.out.println(removeElement1(nums,val));

	}


private static int removeElement1(int[] nums, int val) {
		
		int index=0;
		for(int i=0;i<nums.length;i++)
		{
			if(nums[i]!=val)
			{
				nums[index++]=nums[i];
			}
		}
		for(int i=index;i<nums.length;i++)
		{
			nums[index]=1000;
		}
		
		return index;
	}


//	int[] nums = {0,1,4,0,3,1000,1000,1000}; int  val = 2;
	
	private static int removeElement(int[] nums, int val) {	
		int j=nums.length-1;
		int i=0;
		
		if(nums.length==1 && nums[0]==val) 
		{
		nums[0]=1000;
		return 0;
		}
			while(i<j)
			{
				if(nums[i]==val)
				{
					
					while(nums[j]==val)
					{
						nums[j]=1000;
						if((j-1)>i) j--;
						else break;
					}
					nums[i]=nums[j];
					nums[j]=1000;
					j--;
				}
				
				i++;
				if(i==j & nums[i]==val) nums[i]=1000;
			}
			i=0;
			
			for(int k=0;k<nums.length;k++)
			{
				if(nums[k]==1000)
				{
					break;
				}
				i++;
			}
			
				
		
		return i;
	}

}

package LeetCode;

import java.util.ArrayList;
import java.util.List;

public class PermutationSequence_60 {

	public static void main(String[] args) {
		
//		int n = 3; int k = 3;
		int n = 4; int k = 9;
//		int n = 3; int k = 1;
		
		System.out.println(getPermutation(n,k));

	}

	
	//[1 , 2 , 3 ]
	// 0   1   2
	private static String getPermutation(int n, int k) {
		k=k-1;
		StringBuilder builder=new StringBuilder();
		int b=0;
		List<Integer> list= new ArrayList<Integer>();
		for(int i=1;i<=n;i++)
		{
			list.add(i);
		}		
		while(!list.isEmpty())
		{
			b=fact(n-1);
			int index=k/b;			
			builder.append(list.remove(index));			
			k=k%b;
			n--;
		}
		return builder.toString();
	}	
	public static int fact(int n)
	{
		int fact=1;
		while(n>0)
		{			
		 fact=fact*n;
		 n--;
		}
		return fact;			
	}
}

package LeetCode;

public class ReverseInteger_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int inputNo= 1534236469;
		System.out.println(reverseInteger(inputNo));		
	}

	private static int reverseInteger(int x) {
		
		int n=0;
		int intNo;
		if(x<0)
		{
			x=0-x;
			n++;
		}
		
		long reversex=0;
		if(x%10==0)
		{
			x=x/10;
		}
		for (;x>0;x=x/10)
		{
			int r=x%10;
			reversex=reversex*10+r;
			if(reversex> 2147483647 || reversex<-2147483647 )
			{
				return 0;
			}
		}	
		if (n==1)
		{
			reversex=0-reversex;
		}		
		return intNo=(int)reversex;
	}

}

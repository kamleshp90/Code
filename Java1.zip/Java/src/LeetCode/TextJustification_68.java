package LeetCode;

import java.util.ArrayList;
import java.util.List;

public class TextJustification_68 {														

	public static void main(String[] args) {
		
//		String[] words= {"This", "is", "an", "example", "of", "text", "justification."};
//		String[] words = {"What","must","be","acknowledgment","shall","be"};
		String[] words = {"Science","is","what","we","understand","well","enough","to","explain","to","a","computer.","Art","is","everything","else","we","do"};
		int maxWidth=16;
		String str="";
		int spacesToFill=0;
		int spaceCount=0;
		int extraSpaces=0;
//		StringBuilder builder=new StringBuilder();
		
		List<String> output=new ArrayList<String>();
		for(int i=0;i<words.length;i++)
		{
			if((str.length()+words[i].length()<=maxWidth))
			{
				str=str+words[i]+" ";
			}
			else
			{
				str=str.trim();
				String [] word=str.split(" ");
				if(word.length>1)
				{
				spaceCount=maxWidth-str.length();		
				spacesToFill=spaceCount/(word.length-1);
				extraSpaces=spaceCount%(word.length-1); 
				output.add(rightJustify(str,spacesToFill,extraSpaces));		
				}
				else
				{
					output.add(leftJustify(str.trim(),maxWidth));		
				}
				str="";
				i=i-1;
			}
			if(i==words.length-1)
			{
				output.add(leftJustify(str.trim(),maxWidth));	
			}
		}
		for(String sr:output)
		{
			System.out.println(sr);
		}
	}

	private static String leftJustify(String str, int maxWidth) {
		StringBuilder sb=new StringBuilder(str);		
		return sb.append(" ".repeat(maxWidth-str.length())).toString();
}

	private static String rightJustify(String str, int spacesToFill, int extraSpaces) {				
		String[] words=str.split(" ");
		StringBuilder sb=null;
		String newStr="";
		int extraSpacesToAdd=extraSpaces;
		for(int i=0;i<words.length;i++)
		{
			 sb=new StringBuilder(newStr+words[i]);
			 if(i<words.length-1)
			 {
				 if(extraSpacesToAdd>0)
				 {
					 newStr=sb.append(" ".repeat(spacesToFill+2)).toString();
					 extraSpacesToAdd--;
				 }
				 else
				 {
					 newStr=sb.append(" ".repeat(spacesToFill+1)).toString();
				 }
			 }
		}
		return sb.toString();
	}


}




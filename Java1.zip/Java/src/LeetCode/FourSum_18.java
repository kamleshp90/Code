package LeetCode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FourSum_18 {

	public static void main(String[] args) {
		
//		int [] nums = {1,0,-1,0,-2,2}; int target = 0;
//		int [] nums = {-3,-1,0,2,4,5}; int target = 0;
//		int [] nums = {-2,-1,-1,1,1,2,2} ; int target = 0;
		int [] nums = {1000000000,1000000000,1000000000,1000000000};
				int target =-294967296;
				

//		Arrays.sort(nums);
//		for(int n:nums)
//		{
//			System.out.print(n+",");
//		}
		for(List<Integer> i: fourSum(nums, target))
		{
			System.out.println(i);
		}


	}	
	
//	int [] nums =  {-2,-1,-1,1,1,2,2}

	public static List<List<Integer>> fourSum(int[] nums, int target)
	{
		Arrays.sort(nums);
		List<List<Integer>> list=null;
		Set<List<Integer>> arrSet=new HashSet<>();
		int lo=0;
		int hi=0;
		for(int i=0;i<nums.length-3;i++)
		{
			if(i==0 || nums[i]!=nums[i-1])
			{
			
		for(int j=i+1;j<nums.length-2;j++)
		{			
				lo=j+1;
				hi=nums.length-1;
				while(lo<hi)
				{
					long sum=(nums[i]+nums[j]);
					sum=sum+nums[lo]+nums[hi];
					if(sum==target)
					{
						List<Integer> arrs=new ArrayList<Integer>(Arrays.asList(nums[i],nums[j],nums[lo],nums[hi]));
						Collections.sort(arrs);
						arrSet.add(arrs);
						lo++;
						
					}
					else if(nums[i]+nums[j]+nums[lo]+nums[hi]<target) 
					{
						while(nums[lo+1]==nums[lo] && (lo+1)<hi) lo++;
						lo++;
					}
						
					else 
					{
						while(nums[hi-1]==nums[hi] && (hi-1)>lo) hi--;
						hi--;
					}					
				}
		}
		}
			else continue;
	}
	
		return list=new ArrayList<>(arrSet);

	}
	
	
	
}



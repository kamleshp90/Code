package LeetCode;

import java.util.Arrays;

public class MinimumWindowSubstring_76 {

	
	
	static int id=222;
	int ns=23;
	
	public static void main(String[] args) {
		String s = "ADOBECODEBANC";
		String t = "ABC";
		MinimumWindowSubstring_76 c=new MinimumWindowSubstring_76();
		MinimumWindowSubstring_76 d=new MinimumWindowSubstring_76();
		c.ns=45;
		c.id=54;
		d.ns=00;
		d.id=00;
		
		System.out.println(c.ns+" , "+d.ns+"\n"+c.id+" , "+d.id);
		
		
		
		StringBuilder sb=new StringBuilder(t);
		int i = 0;
		int j = i + 1;
		while (j < s.length()) {
			if (sb.toString().indexOf(s.charAt(i)) != -1) {
				sb.deleteCharAt(sb.toString().indexOf(s.charAt(i)));
				if(sb.toString().indexOf(s.charAt(j))!=-1)
				{
					Arrays.asList(new int[] {2,4,5,6});
				}
			}
		}

	}

}

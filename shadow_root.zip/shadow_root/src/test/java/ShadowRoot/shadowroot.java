package ShadowRoot;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class shadowroot {

	public static void main(String[] args) throws InterruptedException {
		
//		System.setProperty("webdriver.chrome.driver","/Users/kamlesh.patle/eclipse-workspace/shadow_root/resources/chromedriver 2");
	//	WebDriverManager.chromedriver().create();
		
		WebDriver driver=WebDriverManager.chromedriver().create();
		
		driver.get("https://books-pwakit.appspot.com/");
//		
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		WebElement books	=	(WebElement)jse.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"app-header > app-toolbar.toolbar-bottom > book-input-decorator > #input\")");
		books.sendKeys("Harry Potter");
		books.sendKeys(Keys.ENTER);
		Thread.sleep(8000);
//		driver.quit();
		
		
		JavascriptExecutor jse1=(JavascriptExecutor)driver;
		WebElement bookUl=	(WebElement)jse.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"main > book-explore\").shadowRoot.querySelector(\"section > ul \")");
		List<WebElement> bookList=bookUl.findElements(By.cssSelector("li"));
		System.out.println(bookList.size());
//		for(int i=0;i<bookList.size();i++)
//		{
//		String bookName=(bookUl.findElement(By.cssSelector("li:nth-child(i) > book-item")).getShadowRoot()).findElement(By.cssSelector("h2.title")).getText();
//		System.out.println(bookName);
//		}
		
		for(int i=1;i<bookList.size();i++)
		{			
//			WebElement bookTitle=	(WebElement)jse1.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"main > book-explore\").shadowRoot.querySelector(\"section > ul > li:nth-child("+i+") > book-item\").shadowRoot.querySelector(\"h2\")");
			
			String bookName=((bookUl.findElement(By.cssSelector("li:nth-child("+i+") > book-item"))).getShadowRoot()).findElement(By.cssSelector("h2.title")).getText();
			System.out.println(bookName);
		}
		driver.quit();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement logo=WebElement(js.executeScript("return document.querySelector(\"ntp-app\").shadowRoot.querySelector(\"div#content > ntp-logo\").shadowRoot.querySelector(\"div#logo\")"));
		
		Select s=new Select(logo);
		s.
	}

	private static WebElement WebElement(Object executeScript) {
		// TODO Auto-generated method stub
		return null;
	}

	private static void WebElement logoWebElement(Object executeScript) {
		// TODO Auto-generated method stub
		
	}
}

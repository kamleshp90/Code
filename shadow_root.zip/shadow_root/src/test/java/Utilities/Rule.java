package Utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import org.openqa.selenium.WebElement;

public class Rule {
	
	private static Predicate<WebElement> elements=(s)-> s.getText().length()==0;
	private static Predicate<WebElement> containsS=(s)-> s.getText().toLowerCase().contains("s");
	
	public static List<Predicate<WebElement>> get()
	{
		List<Predicate<WebElement>> listOfPredicates=new ArrayList<>();
		listOfPredicates.add(elements);
		listOfPredicates.add(containsS);
		return listOfPredicates;
	}
	
	public static Consumer<WebElement> getprinted()
	{
		return (s)-> System.out.println(s.getText());
		
	}

}

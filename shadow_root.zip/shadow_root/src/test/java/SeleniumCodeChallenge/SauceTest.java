package SeleniumCodeChallenge;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SauceTest {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		
		List<WebElement> priceList=driver.findElements(By.className("inventory_item_price"));
		Double maxPrice=priceList.stream().mapToDouble(e->Double.parseDouble(e.getText().replace("$", ""))).max().getAsDouble();
		priceList.stream().forEach(s->System.out.println(s.getText()));
		
		System.out.println(maxPrice);
		driver.findElement(By.xpath("//div[normalize-space()='$"+maxPrice+"']/following-sibling::button[text()='Add to cart']")).click();
		Thread.sleep(10000);
		
	}

}

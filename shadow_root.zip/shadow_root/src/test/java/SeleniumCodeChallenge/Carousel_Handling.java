package SeleniumCodeChallenge;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Carousel_Handling {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		driver.get("https://www.noon.com/");
		
	
		String recomendedList="Recommended for you";
		String brandDeals="noon brands deals";
		String dealsElectronics="Trending deals in electronics";
		String dealsClearance="Clearance deals";
		int i=1;
		for(String s: getItemList(dealsElectronics, driver, wait))
		{
			System.out.println(i+" : "+s);
			i++;
		}		
	}
	
	public static List<String> getItemList(String element, WebDriver driver, WebDriverWait wait) throws InterruptedException
	{
		By swiperButtonDisappeared=By.xpath("//h3[text()='"+element+"']/parent::div/following-sibling::div//div[ends-with(@class,'swiper-button-disabled')]");
		JavascriptExecutor js=(JavascriptExecutor)driver;
		List<String> itemList=new ArrayList<String>();
//		WebElement headerName=;
			
		scrollUntillWebElement(By.xpath("//h3[text()='"+element+"']"), driver, js);		
		List<WebElement> recoItemList=driver.findElements(By.xpath("//h3[text()='"+element+"']/parent::div/following-sibling::div//div[contains(@class,'swiper-slide')]//div[@data-qa='product-name']"));
		int i=1;
		for(WebElement e:recoItemList)
		{
//			Thread.sleep(3000);
			itemList.add(wait.until(ExpectedConditions.visibilityOf(e)).getText());
			if(i==6)
			{
//				System.out.println(itemList.size());
				while(!isElementPresent(swiperButtonDisappeared, driver))
				{
					try {
						driver.findElement(By.xpath("//h3[text()='"+element+"']/parent::div/following-sibling::div//div[starts-with(@class,'swiper-button-next')]")).click();
						break;
					}
					catch(ElementClickInterceptedException c)
					{
						js.executeScript("window.scrollBy(0,500)");
					}
				}			
				i=0;
			}
			i++;
		}
		
		Collections.sort(itemList);
		return itemList;
	}
	
	private static boolean isElementPresent(By swiperButton, WebDriver driver) {
		
		try {
			driver.findElement(swiperButton);
			return true;
		}
		catch(NoSuchElementException f)
		{
			return false;
		}
		
	}

	public static WebElement scrollUntillWebElement(By by, WebDriver driver, JavascriptExecutor js)
	{
		
		boolean elementFound=false;
		while(!elementFound)
		{
			try {
				driver.findElement(by);
				elementFound=true;
			}
			catch(NoSuchElementException e)
			{
				js.executeScript("window.scrollBy(0,500)");
			}
		}
		return driver.findElement(by);
	}


}

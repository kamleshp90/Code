package SeleniumCodeChallenge;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrokenLinkWithParallelStream {
	
	public static void main(String[] args) throws MalformedURLException, IOException {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

		driver.get("https://www.amazon.in/");
		List<String> urls=new ArrayList<String>();
		
		List<WebElement> links=driver.findElements(By.tagName("a"));
		links.stream().forEach(s->urls.add(s.getAttribute("href")));
		
		System.out.println(urls.size());
		
		
		//use parallelStream instead of stream for fast execution
		long strtTime=System.currentTimeMillis();		
		urls.parallelStream().forEach(url->{
			try {
				checkBrokenLink(url);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});	
		long endTime=System.currentTimeMillis();
		
		System.err.println("total time : "+(endTime-strtTime));
	}

	private static void checkBrokenLink(String url) throws MalformedURLException, IOException {
		
		HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
		conn.setRequestMethod("HEAD");
		conn.connect();
		if(conn.getResponseCode()>=400)
		{
			System.out.println(url+" :  ***********>LINK IS BROKEN");
		}
		else
		{
			System.out.println(url);
		}
	}
	
	
	
	

}

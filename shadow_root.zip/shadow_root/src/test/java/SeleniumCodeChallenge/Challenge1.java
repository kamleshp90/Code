package SeleniumCodeChallenge;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Challenge1 {

	public static void main(String[] args) {
		WebDriver driver = WebDriverManager.chromedriver().create();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		driver.get("https://www.zoopla.co.uk/");
		driver.findElement(By.xpath("//input[@placeholder='Enter a city, town or postcode']")).sendKeys("London");
		driver.findElement(By.xpath("//ul[@role='listbox']//li[1]")).click();
		driver.findElement(By.xpath("//button[.='Search']")).click();

		// pricelist
		scrollToBottom(driver);
		List<WebElement> priceList = driver.findElements(By.xpath(
				"//div[@data-testid='regular-listings']//div[contains(@id,'listing')]//*[@data-testid='listing-price']"));
		scrollToTop(driver);

		List<Integer> numPriceList = priceList.stream().map(n -> numericValue(n.getText())).sorted()
				.collect(Collectors.toList());
		Collections.reverse(numPriceList);
		numPriceList.stream().forEach(s -> System.out.println(s));

		// clickOn5th property
		clickOn(driver, priceList.get(4));

		// agentdetails

		WebElement agent = wait.until(ExpectedConditions.visibilityOf(driver
				.findElement(By.xpath("//div[@data-testid='agent-details']//*[contains(@class,'css-1q5qety')]"))));
		String agentName = agent.getText();

		String logo = driver.findElement(By.xpath("//div[@data-testid='agent-details']//img[contains(@alt,'Logo')]"))
				.getAttribute("src");
		WebElement callAgent = driver.findElement(By.xpath(
				"//div[@data-testid='agent-details']//*[contains(@class,'css-1jj5e76')]//button[contains(.,'Call agent')] "));
		callAgent.click();
		wait.until(ExpectedConditions.invisibilityOf(callAgent));
		String phoneNo = driver
				.findElement(By.xpath("//div[@data-testid='agent-details']//*[contains(@class,'css-1jj5e76')]"))
				.getText();
		System.out.println("agent logo : " + logo);
		System.out.println("agent name on property : " + agentName);
		System.out.println("agent number : " + phoneNo);

		// clickOnAgent

		driver.findElement(By.xpath("//div[@data-testid='agent-details']//a[@data-testid='agent-image-link']")).click();
		String agentNamePage = waitForElementToAppear(wait, driver.findElement(By.xpath("//h1[@class='bottom-half']")))
				.getText().split(",")[0];
		System.out.println("name on agent page : " + agentNamePage);

	}

	public static int numericValue(String str) {
		return Integer.parseInt(str.replaceAll("[^0-9]", ""));
	}

	public static void scrollToBottom(WebDriver driver) {
		long height = Long
				.parseLong(((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight").toString());
		try {
			while (true) {
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
				Thread.sleep(500);
				long newHeight = Long.parseLong(
						((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight").toString());
				if (newHeight == height)
					break;
				height = newHeight;
			}
		} catch (Exception e) {

		}
	}

	public static void scrollToTop(WebDriver driver) {
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0)");
	}

	public static void scrollToElement(WebDriver driver, WebElement element) {

		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void clickOn(WebDriver driver, WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		while (true) {
			try {
				Thread.sleep(500);
				element.click();
				break;
			} catch (ElementClickInterceptedException e) {
				scrollUp(driver);

			} catch (Exception e) {

			}
		}
	}

	public static void scrollUp(WebDriver driver) {
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-50)");
	}

	public static void isVisible(WebElement element) {
		element.isDisplayed();
	}

	public static WebElement waitForElementToAppear(WebDriverWait wait, WebElement element) {
		return wait.until(ExpectedConditions.visibilityOf(element));
	}
}

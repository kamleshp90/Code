package Assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assign1 {

	public static void main(String[] args) throws InterruptedException {
		

		WebDriver driver=WebDriverManager.chromedriver().create();
		
		driver.get("https://www.zoopla.co.uk/");
		
		
		driver.findElement(By.xpath("//ul[@role='listbox']/li[contains(@id,'item-0')]")).click();
		List<WebElement> e=driver.findElements(By.xpath("//*[@data-testid='regular-listings']//*[@data-testid=\"listing-price\"]"));
		
		List<Integer> sortedPrice=new ArrayList<Integer>();
				
		for(int i=0;i<e.size();i++)
		{
			sortedPrice.add(Integer.valueOf(e.get(i).getText().replace("£", "")));
		}
		Collections.sort(sortedPrice);
		e.get(4).click();
		Thread.sleep(5000);
		
		if(System.out.printf("ds")==null)
		{
			
		}
		
		
		

	}

}

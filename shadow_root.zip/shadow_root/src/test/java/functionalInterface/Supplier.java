package functionalInterface;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Utilities.Rule;
import driverFactory.DriverFactory;
import shadow_rootpages.TablePage;

public class Supplier {

	private WebDriver driver;
	private TablePage tablePage;

	@BeforeTest
	public void setBrowse() throws InterruptedException {
		this.driver = DriverFactory.getDriver("chrome");
		 tablePage=new TablePage(driver);

	}
	
	@AfterMethod
	public void afterMethod() throws InterruptedException
	{
		Thread.sleep(5000);
	}

	@Test
	public void checkboxSelection() {
		List<WebElement> cbLinks = driver.findElements(By.xpath("//tbody//td/input[@type='checkbox']"));
		cbLinks.stream().forEach(e-> e.click());
	}
	@Test(dataProvider="genderProvider")
	public void genderBasedCheckboxSelection(String gender) {
//		String gender="Female";
		List<WebElement> cbLinks = driver.findElements(By.xpath("//tbody//td[text()='"+gender+"']/following-sibling::td/input"));
		cbLinks.stream().forEach(e-> e.click());
	}
	
	@Test(dataProvider="criteriaProvider")
	public void genderBasedCheckboxSelection1(Predicate<List<WebElement>> criteria) {
		tablePage.goTo();
		tablePage.tickCheckBox(criteria);
		
	}
	
	@DataProvider(name= "criteriaProvider")
	public Object[] getData()
	{
		Predicate<List<WebElement>> allMale=tdList->tdList.get(1).getText().equalsIgnoreCase("Male");
		Predicate<List<WebElement>> allFemale=tdList->tdList.get(1).getText().equalsIgnoreCase("Female");
		Predicate<List<WebElement>> countryUK=tdList->tdList.get(2).getText().equalsIgnoreCase("UK");
		Predicate<List<WebElement>> allGender=allMale.or(allFemale);
		Predicate<List<WebElement>> FemaleUK=allFemale.and(allFemale);
		return new Object[] {allMale,
							allFemale,
							countryUK,
							allGender,
							FemaleUK};
	}

	@Test
	void run() throws InterruptedException {
		Predicate<WebElement> isBlank = (s) -> s.getText().length() == 0;
		Predicate<WebElement> containsS = (s) -> s.getText().toLowerCase().contains("s");
		Consumer<WebElement> printText = (s) -> System.out.println(s.getText());

		List<WebElement> links = driver.findElements(By.tagName("a"));
		links.removeIf(isBlank);
		links.removeIf(containsS);
		Thread.sleep(5000);
		links.forEach(printText);
	}

	@Test
	public void run1() {
		List<WebElement> links = driver.findElements(By.tagName("a"));
		Rule.get().forEach(links::removeIf);
		links.forEach(Rule.getprinted());
	}

}

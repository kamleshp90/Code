package driverFactory;


import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
	
	private static final WebDriver chromeSupplier()
	{
		return  WebDriverManager.chromedriver().create();
	}
	
	private static final WebDriver fireFoxSupplier()
	{
		return  WebDriverManager.firefoxdriver().create();
	}
	
	private static final Map<String ,WebDriver > MAP=new HashMap<String ,WebDriver>();
	
	static {
		MAP.put("chrome", chromeSupplier());
		MAP.put("firefox", fireFoxSupplier());
	}

	public static WebDriver getDriver(String browser)
	{
		return MAP.get(browser);
	}
	
//	public static void main(String[] args) {
//		
//	}
}

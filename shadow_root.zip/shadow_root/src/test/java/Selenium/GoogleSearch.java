package Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearch {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=WebDriverManager.chromedriver().create();
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		
		driver.get("https://www.google.co.in/");
		
		driver.findElement(By.xpath("//input[@title='Search']")).sendKeys("testing");
		
		
		List<WebElement> list=wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//ul[@role='listbox']/li//div[@class='wM6W7d']/span")))) ;

		for(WebElement e:list)
		{
			if (e.getText().equalsIgnoreCase("testing tools"))	
			{
				e.click();
//				Thread.sleep(5000);
				break;
			}
			
		}
	}

}

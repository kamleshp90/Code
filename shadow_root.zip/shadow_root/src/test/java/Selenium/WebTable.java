package Selenium;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebTable {

	public static void main(String[] args) {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.get("https://www.icc-cricket.com/rankings/mens/team-rankings/test");
		List<String> teamDetails= new ArrayList<String>();
		
		teamDetails=getTeamDetails("India", driver);
		System.out.println(teamDetails);
	}
	

	public static List<String> getTeamDetails(String team, WebDriver driver ) {
		
		
		List<WebElement> list=driver.findElements(By.xpath("//table[@class='table']/tbody/tr"));
		List<String> teamDetails= new ArrayList<String>();
		for(int i=1;i<list.size();i++)
		{
			WebElement teamName=driver.findElement(By.xpath("//table[@class='table']/tbody/tr["+i+"]/td[2]/span[2]"));
			if (teamName.getText().equalsIgnoreCase(team))
			{
				for(int j=3;j<=5;j++)
				{
					
					teamDetails.add(driver.findElement(By.xpath("//table[@class='table']/tbody/tr["+i+"]/td["+j+"]")).getText());
				}
			}
			
		}
		
		return teamDetails;
	}
	
	
}



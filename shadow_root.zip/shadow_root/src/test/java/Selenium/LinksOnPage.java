package Selenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LinksOnPage {

	public static void main(String[] args) throws MalformedURLException, IOException {
		
		int resCode=0;
		WebDriver driver=WebDriverManager.chromedriver().create();

/*		
		
		driver.get("https://www.udemy.com/");
		List<WebElement> urls=driver.findElements(By.xpath("//a[@href]"));
//		Map<Integer,String> hmap=new HashMap<Integer, String>();
		for(WebElement url:urls)
		{
			String link=url.getAttribute("href");
			HttpURLConnection con=(HttpURLConnection) new URL(link).openConnection();
			con.setRequestMethod("HEAD");
			con.connect();
			resCode=con.getResponseCode(); 
			System.out.println(resCode+"-->"+link);
//			hmap.put(resCode, link);
		}
//		for(Map.Entry<Integer,String> e:hmap.entrySet())
//		{
//			System.out.println(e.getKey()+"-->"+e.getValue());
//		}

*/
		driver.get("https://www.google.co.in/");
		driver.findElement(By.xpath("//a[@aria-label='Google apps']")).click();

	}

}

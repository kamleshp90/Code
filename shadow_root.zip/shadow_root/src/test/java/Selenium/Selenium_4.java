package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Selenium_4 {

	public static void main(String[] args) {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.get("https://www.udemy.com/join/signup-popup/?locale=en_US&response_type=html&next=https%3A%2F%2Fwww.udemy.com%2Flogout%2F");
		WebElement form1=driver.findElement(By.cssSelector("input#form-group--1"));
//		driver.findElement(with(By.tagName("input")).below(By.id("form-group--1"));
		
		form1.getScreenshotAs(OutputType.FILE);
		form1.getRect().getDimension().getHeight();
		form1.getRect().getDimension().getWidth();
		driver.switchTo().newWindow(WindowType.TAB);
	}

}

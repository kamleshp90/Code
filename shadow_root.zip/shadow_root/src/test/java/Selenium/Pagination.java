package Selenium;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Pagination {

	public static void main(String[] args) throws InterruptedException {
	
	WebDriver driver=	WebDriverManager.chromedriver().create();
	
	driver.get("https://datatables.net/examples/advanced_init/dt_events.html");
	
	
	List<String> namesList=new ArrayList<String>();
	List<WebElement> pages=driver.findElements(By.xpath("//div[@id='example_paginate']/span/a"));
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	
	
	for(int i=0;i<pages.size();i++)
	{

		if(i>0)
		{
			driver.findElement(By.xpath("//div[@id='example_paginate']/a[@class='paginate_button next']")).click();
		}
		List<WebElement> names=driver.findElements(By.xpath("//table[@id='example']//tbody/tr/td[1]"));
		for(WebElement name:names)
		{
			namesList.add(name.getText());
		}	
	}
	
	System.out.println(namesList.size());
	
	
			

	}

}

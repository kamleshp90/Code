package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Canvas {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.get("https://kitchen.applitools.com/ingredients/canvas");
		WebElement canvas=driver.findElement(By.id("burger_canvas"));
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);",canvas);
		
		Dimension canvasDimensions=canvas.getSize();
		int canvasX=(canvasDimensions.getWidth())/2;
		int canvasY=(canvasDimensions.getHeight())/2;
		
		int offsetX=(canvasX/3)*2;
		int offsetY=(canvasY/3)*2;
		System.out.println(canvasX+"   , "+canvasY);
		System.out.println(offsetX+"   , "+offsetY);
		
		Actions act=new Actions(driver);
		act.moveToElement(canvas,offsetX,offsetY).click().perform();
		
		
		Thread.sleep(20000);

	}

}

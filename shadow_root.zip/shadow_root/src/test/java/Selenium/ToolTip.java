package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ToolTip {

	public static void main(String[] args) {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.get("https://selectorshub.com/xpath-practice-page/");
		driver.findElement(By.id("userId")).sendKeys("automation@");
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		
		String msg=driver.findElement(By.id("userId")).getAttribute("validationMessage");
		System.out.println(msg);
		
		

	}

}

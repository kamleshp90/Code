package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ActionEx {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=WebDriverManager.chromedriver().create();
		driver.get("https://www.w3schools.com/html/html5_draganddrop.asp");
		WebElement from=driver.findElement(By.xpath("//*[text()='Example']/following-sibling::div[@id='div1']/child::img"));
		WebElement to=driver.findElement(By.xpath("//*[text()='Example']/following-sibling::div[@id='div1']/following-sibling::div[1]"));
		
		Actions act=new Actions(driver);
		act.dragAndDrop(from, to).perform();
		Thread.sleep(5000);
		

		}

}

package Java_basics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StringPrg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		StringBuilder builder=new StringBuilder();
//		String [] names= {"John","Mike","Atlas","Jemmy"};
//		for(String s:names)
//		{
//			builder.append(s);
//		}
//		
//		System.out.println(builder);
//		
//		builder.toString();
//		System.out.println(builder);
		
		String s="Awesome";
		
		int[] a= {3,5,6,5};
		
		Arrays.stream(a).boxed().collect(Collectors.toList());
		
		s.contains("some");
		
		
		String[] c=s.split("");
		List<String> alist=Arrays.asList(c);
		
		Collections.reverse(alist);
		String revString=alist.toString();
		System.out.println(revString);
		
	
		
		
		
		
	}

}

package Java_basics;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class RemoveDuplicates {

	public static void main(String[] args) {									
		// TODO Auto-generated method stub
																		
//		int [] nums = {1,0,0,0,0,0,0,0,0};	
//		int [] nums = {1,2};	
		int [] nums = {0,0,1,1,1,1,2,3,3};
		
		System.out.println(removeDuplicates2_1(nums));
	
//		Set<Integer> hset=new HashSet<Integer>();
//		hset.add(1001);
//		int k=1;
//		
//        for(int i=1;i<nums.length;i++)
//        {            
//                if(nums[i-1]!=nums[i] && !hset.contains(nums[i]))
//                {
//                    nums[k]=nums[i];                   
//                    if(k!=i)
//                    {
//                    	hset.add(nums[i]);
//                    	nums[i]=1001;                    	
//                    }
//                    k++;                    
//                }
//                else
//                {                    
//                    hset.add(nums[i]);
//                    nums[i]=1001;
//                }          
//         }
//        
//       for(int i:nums)
//       {
//    	   System.out.println(i);
//       }
//       System.out.println(k);
//  
		
       
	}
	
	//int [] nums = {0,0,1,1,1,1,2,3,3};
//80. Remove Duplicates from Sorted Array II
	private static int removeDuplicates2(int[] nums) {
		int index=0;
		int num=0;
		Map<Integer,Integer> hmap=new LinkedHashMap<>();
		for(int i:nums)
		{
			num=hmap.containsKey(i) ? num+1 : 1;
			hmap.put(i, num);
		}
		for(int i=0;i<nums.length;i++)
		{
			if(hmap.get(nums[i])>2)
			{
				for(int j=0;j<2;j++) nums[index++]=nums[i];
				i=i+hmap.get(nums[i])-1;
				continue;
			}
			nums[index++]=nums[i];
		}
		for(int i=index;i<nums.length;i++)
		{
			nums[i]=100000;
		}		
		
		for(int i:nums)
		{
			System.out.print(i+" , ");
		}		
		return index;
		
	}

	
	private static int removeDuplicates2_1(int[] nums)
	{
		int i=0;int j=0;
		
		while(j<nums.length)
		{
			if(i<2 || nums[i-2]<nums[j])
			{
				nums[i++]=nums[j++];
			}
			else j++;
		}
		for(int k:nums)
		{
			System.out.print(k+" , ");
		}		
		return i;
	}
	
	
	//int [] nums = {0,0,1,1,1,2,2,3,3,4,4,4,4,4,5};	
	private static int removeDuplicates(int[] nums) {
		
		int index=1;
		for(int i=1;i<nums.length;i++)
		{
			if(nums[i]!=nums[i-1])
			{
				nums[index++]=nums[i];			
			}
		}
		for(int i=index;i<nums.length;i++) nums[i]=1001;
		
		 for(int i:nums)
	       {
	    	   System.out.println(i);
	       }
		
		return index;
	}

}

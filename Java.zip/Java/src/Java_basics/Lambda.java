package Java_basics;

public class Lambda {

	public static void main(String[] args) {
		
		
		
		
//		MyFunctionalInterface i=(a,b)->  System.out.println(a+b);
//		i.printMethod(4,7);
		
//		MyFunctionalInterface i=(s)-> s.length();
//		int a=i.length("Kamlesh");
//		System.out.println(a); 
		
//		MyFunctionalInterface i=(a)-> {
//			int x =a*8;
//			return x/2;
//		};
		
//		int a=i.calc(45);
//		System.out.println(a);
		
		MyFunctionalInterface i=()->System.out.println("print method");
		
		i.printMethod();
		
		

		
		
	}

}
@FunctionalInterface
interface MyFunctionalInterface
{
	public void printMethod();
//	public int length(String s);
//	public int calc(int a);
}

//  class CallFunctionalInterface implements MyFunctionalInterface
//{
//	@Override
//	public void printMethod(int a , int b)
//	{
//		System.out.println("funmethod");
//	}
//}

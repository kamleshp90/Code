package Java_basics;

import java.awt.RenderingHints.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.swing.JComboBox.KeySelectionManager;

public class Streams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		List<Integer> list= new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		
		List<Integer> iList=Arrays.asList(10,45,23,67,44,22);
		
		iList.stream().filter(s->s%2==0).forEach(s->System.out.println(s));
		iList.stream().map(s->s*2).anyMatch(s->s%2!=0);
		
		
		
		Arrays.asList(10,34,67,89,23,15,94).stream().sorted().toList();
		
		int[] a= {10,34,67,89,23,15,94};
		a.toString();
		System.out.println(a.toString());
		
		
		
//		list.stream().forEach(i-> System.out.println(i));
		
//		System.out.println(Collections.min(list));
//		System.out.println(Collections.max(list));
		
//		long l=list.stream().filter(s->s>30).limit(1).count();
//		System.out.println(l);
//		
//		boolean b=list.stream().anyMatch(s->s>30);
//		System.out.println(b);
		
		
		
	}

}

package Java_basics;

import java.util.ArrayList;
import java.util.List;

public class Combination_Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int [] candidates = {2,3,6,7};
		int target = 7;
		int sum;
		List<List<Integer>> list=new ArrayList<List<Integer>>();
		for(int i=0;i<candidates.length-1;i++)
		{
			for(int j=i+1;j<candidates.length;j++)
			{
				sum=candidates[i]+candidates[j];
				if(sum==target)
				{
					break;
				}
			}
		}				
	}
}

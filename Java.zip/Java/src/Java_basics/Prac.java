package Java_basics;

import java.util.function.Predicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import Interface.MyInterface;




public  class Prac implements  MyInterface{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Predicate<Integer> p=(s)->s%2==0;
		boolean b=p.test(8);
//		System.out.println(b);
		
		Function<String,String> f=(s)->
		{
			StringBuilder r=new StringBuilder();
			for(int i=s.length()-1;i>=0;i--)
			{
				r.append(s.charAt(i));
			}
			return r.toString();
		};
		
		
		
//		Function<String,Integer> f=(s)-> s.length()*2;
		String s="India is my country";
		String[] sArray=s.split(" ");
		for(int i=sArray.length-1;i>=0;i--)
		{
			System.out.println(f.apply(sArray[i]));
		}
		
		Consumer<String> c=(cs)-> System.out.println(s);
		
		Supplier<Integer> s1=()->"String".length();
		
				
		
		
//		MyInterface m=()->System.out.println("Print");
//		m.print();
		
		
		
//		Prac pr=new Prac();
//		pr.Hello();
		
		
		
	
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void Hello() {
		System.out.println("Overrided Hello");
		
	}

}

package Java_basics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Integer> hmap=new HashMap<String,Integer>();
		
		hmap.put("Kalishka", 1);
		hmap.put("Kishika", 2);
		hmap.put("Nisika", 4);
		hmap.put("Diksha", 3);
		hmap.put("Aalisha", 3);
		
//		for(Map.Entry<String,Integer> e : hmap.entrySet())
//		{
//			System.out.println(e.getKey()+" : "+e.getValue());
//			
//			
//		}
		
		
		System.out.println(hmap.containsKey("Nisika"));
		System.out.println(hmap.containsValue(3));
		
		
		
		
		
		ArrayList<String> s=new ArrayList<String>(hmap.keySet());
		ArrayList<Integer> i=new ArrayList<Integer>(hmap.values());
		
		for(String si:s)
		{
			System.out.println(si);
		}
		
		for(Integer si:i)
		{
			System.out.println(si);
		}
		
		Set<Integer> hs=new HashSet<Integer>();
		hs.add(1);
		hs.add(3);
		hs.add(9);
		
		int[] a= {3,4,5,6,-10,7,-5,9};
		
		int sum=0;
		
		for(int i1:a)
		{
			System.out.println(i1);
			int n=(i1>0)? i1:0;
			sum=sum+n;
		}
		System.out.println(sum);
		
		
		
		

	}

}

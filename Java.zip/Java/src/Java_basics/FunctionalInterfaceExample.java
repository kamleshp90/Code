package Java_basics;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Consumer;
import java.util.function.Supplier;
public class FunctionalInterfaceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Predicate
		Predicate<String> p=(s)-> s.length()>5;
		boolean b=p.test("Automation");
		System.out.println(b);
		
		//Function
//		Function<String,Integer> f=(s)->s.length()*2;
//		int l=f.apply("Automation");
//		System.out.println(l);
		
		//Consumer
		Consumer<String> c=(s)-> System.out.println(s.length());
		c.accept("automation");
		
		//Supplier
		Supplier<String> s=()-> "automation";
		System.out.println(s.get());
		
		Supplier<Integer> i=()-> "automation".length();
		System.out.println(s.get());
		
	

	}

}

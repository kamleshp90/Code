package Interface;

public interface MyInterface {

	public void print();
	public default void Hello()
	{
		System.out.println("Hello");
	}
	public static void pStatic()
	{
		System.out.println("Static");
	}
	
}

package LeetCode;

public class NumberOfArithmeticTriplets_2367 {

	public static void main(String[] args) {
		

		int[] nums = {0,1,4,6,7,10}; int diff = 3;
		
		System.out.println(arithmeticTriplets(nums,diff));

	}
	
	public static int arithmeticTriplets(int[] nums, int diff) {
        
		int count=0;
		for(int i=0;i<nums.length-2;i++)
		{
			
			int j=i+1;
			int k=j+1;
			
			while(j<nums.length-1)
			{
				if(nums[j]-nums[i]==diff)
				{
					while(k<nums.length)
					{
						if(nums[k]-nums[j]==diff)
						{
							count++;
							break;
						}
						else k++;
					}
					break;
				}
				else j++;		
			}
		}
		return count;
		
		
    }

}

package LeetCode;

public class RearrangeSpacesBetweenWords_1592 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		String text="  this   is       a sentence ";
//		String text=" practice   makes   perfect";
		String text="a";
		System.out.println(rearrangeString(text));
		

	}
	
	public static String rearrangeString(String text)
	{
		 String[] word=text.trim().split("\\s+");
			StringBuilder builder=new StringBuilder();
			
			int spaceCount=text.length()-text.replaceAll("\\s", "").length();
	        if(word.length>1)
	        {
			int spaces=spaceCount/(word.length-1);
			int extraSpace=spaceCount%(word.length-1);
			for(int i=0;i<word.length;i++)
			{
				if(i<word.length-1)
				{
					builder.append(word[i]);
					builder.append(" ".repeat(spaces));
					
				}
				else
				{
					builder.append(word[i]);
	                if(extraSpace>0)
				    {
					    builder.append(" ".repeat(extraSpace));
				    }
				}
	            
				
			}
			
			return builder.toString() ;
	        }
	        else
	        {
	            builder.append(word[0]) ;
	            return builder.append(" ".repeat(spaceCount)).toString(); 
	        }
	     
	}

}

package LeetCode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NextPermutation_31 {

	public static void main(String[] args) {
		

//		int[] nums = {1,2,3};
		int[] nums = {3,2,1};
//		int[] nums = {1,1,5};
//		int[] nums = {1,2,4,6,5,3};

//		int[] nums = {1,2,4,6,5,3};			{1,2,5,3,4,6};	

		
		for(int n:nextPermutation(nums))
		{
			System.out.print(n+" , ");
		}

	}

	private static int[] nextPermutation(int[] nums) {
		
		for(int i=nums.length-1;i>0;i--)
		{
			if(nums[i-1]<nums[i])
			{
				int j=nums.length-1;
				while(nums[i-1]>nums[j])
				{
					j--;
				}
				swap(i-1,j,nums);
				reverse(i,nums.length-1,nums);
				return nums;
			}
		}
//		Arrays.sort(nums);
		return nums;
	}

	private static int[] reverse(int i, int j, int[] nums) {
		
		while(i<j)
		{
			swap(i,j,nums);
			i++; j--;
		}
		return nums;
	}

	private static int[] swap(int i, int j, int[] nums) {
		
		int d=0;
		d=nums[i];
		nums[i]=nums[j];
		nums[j]=d;
		return nums;
	}

	
// Invalid soln:
	/*
	private static int[] nextPermutation(int[] numss) {
//		List<Integer> list=Arrays.stream(nums).boxed().collect(Collectors.toList());
		List<Integer> permutationsList=new ArrayList<>();
		
		for(int i=numss.length-1;i>0;i--)
		{
			if(numss[i-1]<numss[i])
			{
				int j=0;
				while(j<numss.length)
				{
					if(j<i-1) 
					{
						permutationsList.add(numss[j]);
						numss[j]=-1;
					}
					
					
					else
					{
						permutationsList.add(successiveHigherInteger(i-1,numss));
						break;
					}				
					j++;
				}				
				while(permutationsList.size()!=numss.length)
				{
					for(int n:getSortedArray(i-1,numss,permutationsList))
					permutationsList.add(n);
				}
				int k=0;
				for(int n:permutationsList)
				{
					numss[k]=n;
					k++;
				}
					
					
				return numss;			
			}
			
		}
		
			Arrays.sort(numss);
			return numss;	
	}
	
	public static int successiveHigherInteger(int n, int[] nums)
	{
		int d=0;
		for(int i=n+1;i<nums.length;i++)
		{			
			int a=Integer.MAX_VALUE;
			if(a>(nums[i]-nums[n]) && nums[i]>nums[n])
			{
				a=(nums[i]-nums[n]);
				d=nums[i];
			}
		}
		return d;
	}
	
	public static int[] getSortedArray(int n,int[] nums,List<Integer> permutationsList)
	{
		int[] sortedArray=new int[nums.length-n-1];
		int j=0;
		for(int i=n;i<nums.length;i++)
		{
			
			if(nums[i]!=permutationsList.get(n))
			{
				sortedArray[j]=nums[i];
				j++;
			}
		}
		Arrays.sort(sortedArray);
		return sortedArray;
	}
	
	*/
	
	
	
	
	
	

}

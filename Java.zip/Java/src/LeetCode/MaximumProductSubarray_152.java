package LeetCode;

public class MaximumProductSubarray_152 {

	public static void main(String[] args) {

		int[] nums= {-4,-3,-2};
//		int[] nums= {0,-1,-2};
//		int[] nums= {-2,3,-4};
//		int[] nums= {2,3,-2,4};
//		int[] nums= {-1,-3,10,0,60};
//		int s=maxProduct(nums);
		int s=maxProducts(nums);
		System.out.println(s);
	}

	private static int maxProducts(int[] nums) {
		int maP=nums[0];
		int miP=nums[0];
		int ans=nums[0];
		for(int i=1;i<nums.length;i++)
		{
			int tmp=0;
			tmp=maxInt(miP*nums[i],maP*nums[i], nums[i]);
			miP=minInt(miP*nums[i],maP*nums[i], nums[i]);
			maP=tmp;
			if (ans<maP)	ans=Math.max(maP, miP);
		}
		return ans;
	}
	
	

	private static int minInt(int i, int j, int k) {
		if(i<j)
		{
			if(i<k) return i;
		}
		else if(j<k)
		{
			return j;
		}
		return k;
	}

	private static int maxInt(int i, int j, int k) {
		if(i>j)
		{
			if(i>k) return i;
		}
		else if(j>k)
		{
			return j;
		}
		return k;
	}

	private static int maxProduct(int[] nums) {
		 	int csum=1;
			int maxsum=nums[0];		
			for(int i=0;i<nums.length;i++)
			{
				csum=csum*nums[i];
				if(csum>maxsum) maxsum=csum;
	            if(csum==0) csum=1;
			}
	        csum=1;
	        for(int i=nums.length-1;i>=0;i--)
			{
				csum=csum*nums[i];
				if(csum>maxsum) maxsum=csum;
	            if(csum==0) csum=1;
			}
			return maxsum;	
	}

}

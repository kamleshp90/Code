package LeetCode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class Busroute_815_copy {
	
	
	

	public static void main(String[] args) {
		
		int [][] routes= {{1,2,3},{1,4,5},{5,7},{3,6,7}};
		int source=1;
		int target=7;
		
		
		System.out.println(numBusToDestination(routes,source,target));

	}

	private static int numBusToDestination(int[][] routes, int source, int target) {
		
		
		if(source==target) return 0;
		
		Map<Integer,List<Integer>> g=new HashMap<>();
		
		for(int i=0;i<routes.length;i++)
		{
			for(int j=0;j<routes[i].length;j++)
			{
				List<Integer> buses=g.containsKey(routes[i][j]) ? g.get(routes[i][j]):new ArrayList<>();
				buses.add(i);
				g.put(routes[i][j], buses);
			}
		}
		
		Queue<Integer> q=new LinkedList<>();
		boolean[] ride=new boolean[routes.length];
		q.offer(source);
		int step=0;
		while(!q.isEmpty())
		{
			++step;
			int size=q.size();
			for(int i=0;i<size;i++)
			{
				int cur=q.poll();
				for(Integer bus:g.get(cur))
				{
					if(ride[bus]) continue;
					ride[bus]=true;
					for(int stop:routes[bus])
					{
						if(stop==target) return step;
						q.offer(stop);
					}
				}
			}
		}
		return -1;
		
		
	}

}

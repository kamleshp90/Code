package LeetCode;

import java.util.ArrayList;

public class DivideaStringIntoGroupsofSizek_2138 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "abcdefghij";
		int k = 3;
		char fill = 'x';
		
//		String[] sArr=divideString(s, k, fill);
		String[] sArr=rearrangeString(s, k, fill);
		for(String ds:sArr)
		{
			System.out.println(ds);
		}
	}

	private static String[] rearrangeString(String s, int k, char fill) {
		StringBuilder builder=new StringBuilder();
		ArrayList<String> list=new ArrayList<String>();
		for(char ch:s.toCharArray())
		{
			builder.append(ch);
			if(builder.length()==k)
			{
				list.add(builder.toString());
				builder.setLength(0);
			}
		}
		if(builder.length()>0)
		{
			int count=k-builder.length();
			for(int i=0;i<count;i++)
			{
				builder.append(fill);
			}
			list.add(builder.toString());
		}
		return  list.toArray(new String[list.size()]);
	}

	private static String[] divideString(String s, int k, char fill) {
		

		StringBuilder builder=new StringBuilder();
		String[] dString;
		int r=0;
		if(s.length()%k==0)
		{
			dString=new String[s.length()/k];
		}
		else
		{
			dString=new String[(s.length()/k)+1];
		}
		for(int i=0;i<s.length();i=i+k)								//i=9
		{
			if(i+k<s.length())
			{
				for(int j=i;j<i+k;j++)
				{
					builder.append(s.charAt(j));
				}
				dString[r]=builder.toString();
				r++;
				builder.setLength(0);
			}			
			else
			{
				for(int j=i;j<i+k;j++)
				{
					if(j<s.length())
						builder.append(s.charAt(j));
					
					else
						builder.append(fill);
				}
				dString[r]=builder.toString();
			}
		}
		
		return dString;
	}

}

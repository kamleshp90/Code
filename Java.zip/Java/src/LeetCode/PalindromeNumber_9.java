package LeetCode;

public class PalindromeNumber_9 {

	public static void main(String[] args) {
		int x=232121;
		
		System.out.println(isPalindrome(x));

		

	}
	
	 public static boolean isPalindrome(int x) {
	        if(x<0) return false;
	        else
	        {
	        	int n=x;
	        	int s=0;
	        	for(;n>0;n=n/10)
	        	{
	        		int r=n%10;
	        		s=s*10+r;
	        	}
	        	if(s==x) return true;
	        	else return false;
	        }
	    }

}

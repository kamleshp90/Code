package LeetCode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ThreeSum_15 {

	public static void main(String[] args) {
		
//		int [] nums= {-1,0,1,2,-1,-4};
//		int [] nums= {0,1,1};
		int [] nums= {0,0,0,0};
//		int [] nums= {1,1,1};
//		Arrays.sort(nums);
//		for(int n:nums)
//		{
//			System.out.print(n+",");
//		}
		for(List<Integer> i: threeSum1(nums))
		{
			System.out.println(i);
		}


	}	
//	public static List<List<Integer>> threeSum(int[] nums) {
//        Arrays.sort(nums);
//        List<List<Integer>> ans = new ArrayList();
//        for(int i=0; i<nums.length-2; i++){
//		    if ( nums[i] > 0)  
//			    break;
//            if(i > 0 && nums[i] == nums[i-1])
//                continue;
//            int j=i+1;
//            int k=nums.length-1;
//            while(j<k){
//                int sum = nums[i]+nums[j]+nums[k];
//                if(sum==0){
//                    ans.add(Arrays.asList(nums[i], nums[j], nums[k]));
//                    while( j<k && nums[j] == nums[j + 1])
//                        j++;
//                    while( j<k && nums[k] == nums[k - 1])
//                        k--;
//                    j++;
//                    k--;
//                }
//                if(sum<0){
//                    j++;
//                    continue;
//                }
//                if(sum>0){
//                    k--;
//                    continue;
//                }
//            }
//        }
//        return ans;
//    }
	
	
//	Brute force approach
	
//	int [] nums= {-1,0,1,2,-1,-4};
//	public static List<List<Integer>> threeSum1(int[] nums)
//	{
//		int n=0;
//		List<List<Integer>> a=null;
//		Set<List<Integer>> set=new HashSet<>();
//		Map<Integer,Integer> m=new HashMap<>();
//		for(int i=0;i<nums.length;i++)
//		{			
//			int num=m.containsKey(nums[i]) ? m.get(nums[i])+1 : 1 ;
//				m.put(nums[i], num);
//		}
//		for(int i=0;i<nums.length-2;i++)
//		{
//			for(int j=i+1;j<nums.length-1;j++)
//			{
//				for(int k=j+1;k<nums.length;k++)
//				{
//					if(nums[i]+nums[j]+nums[k]==0)
//					{
//						n++;	
//						List<Integer> list=new ArrayList<Integer>(Arrays.asList(new Integer[]{nums[i],nums[j],nums[k]}));
//						Collections.sort(list);
//						set.add(list);							
//					}
//				}
//			}
//		}
//		if(n>0)
//		 return a = new ArrayList(set);
//		else
//		 return a = new ArrayList();
//	}
	
	public static List<List<Integer>> threeSum1(int[] nums)
	{
		Arrays.sort(nums);
		List<List<Integer>> list=null;
		Set<List<Integer>> arrSet=new HashSet<>();
		int lo=0;
		int hi=0;
		for(int i=0;i<nums.length-2;i++)
		{			
			if(i==0 || nums[i]!=nums[i-1])
			{
				lo=i+1;
				hi=nums.length-1;
				while(lo<hi)
				{
					if(nums[lo]+nums[hi]==(-nums[i]))
					{
						List<Integer> arrs=new ArrayList<Integer>(Arrays.asList(nums[i],nums[lo],nums[hi]));
						Collections.sort(arrs);
						arrSet.add(arrs);
						lo++;
						
					}
					else if(nums[lo]+nums[hi]<(-nums[i])) 
					{
						while(nums[lo+1]==nums[lo] && (lo+1)<hi) lo++;
						lo++;
					}
						
					else 
					{
						while(nums[hi-1]==nums[hi] && (hi-1)>lo) hi--;
						hi--;
					}					
				}
			}
			else continue;
		}
		return list=new ArrayList<>(arrSet);

	}
	
	
	
}



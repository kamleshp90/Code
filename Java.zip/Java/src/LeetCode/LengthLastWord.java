package LeetCode;

public class LengthLastWord {

	public static void main(String[] args) {
		
//		String s="Hello world ";
		String s="   fly me   to   the moon  ";
		String[] sarr=s.split(" ");
		int length=sarr[sarr.length-1].length();
		System.out.println(length);

	}

}

require 'net/http'
require 'json'
require 'httparty'


url = 'https://reqres.in/api/users/2'
uri = URI(url)
response = Net::HTTP.get(uri)
res=JSON.parse(response)
puts res["data"]["first_name"]



# url = 'https://api.spotify.com/v1/search?type=artist&q=tycho'
# response = HTTParty.get(url)
# res=response.parsed_response
# puts res["error"]









module Calus 

def add(a,b)
    a+b
end

def self.sub(a,b)
    a-b
end

def multiply(a,b)
    a*b
end

PI=3.14

end
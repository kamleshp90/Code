require 'json'
require 'yaml'

#file open
# File.open("sampletext.txt").each  do |line|
#     puts line
# end

File.open("sampletext.txt","r")  do |file|
    #  puts file.read()                                #returns data in the form of string, so we can apply string methods
    # puts file.readline                               # reads first line
    # puts file.readlines[3]                           # readlines=> returns an array of lines

end

File.open("sampletext.txt","a") do|file|
    file.write("Have a good day!")
end

#parse json file
file=File.read('sample.json')
data=JSON.parse(file)
puts data["name"]



#Yaml file

file= YAML.load_file("prefs.yml")
file.read
end



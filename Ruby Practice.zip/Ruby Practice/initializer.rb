
class Book
    attr_accessor:title, :auther
 

    def initialize(title,auther)
        @title=title
        @auther=auther
    end

    def readbook()
        puts "Reading #{self.title} by #{self.auther}"
    end

    def writebook()
        puts "I am writing a book"
    end



    # book=Book.new("Harry", "Rowling")
    # book.readbook()
end

class Library<Book
    attr_accessor:lib_name

    def initialize(lib_name)
        @lib_name=lib_name
    end

    def readbook()
        puts "reading book in #{lib_name}"
    end
    
end

lib=Library.new("Vasant")
lib.readbook()

# lib=Library.new("vasant")
# lib.writebook()

# book=Book.new("Harry", "Rowling")
# book.readbook()


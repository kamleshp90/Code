#while

i=0
while i<5
    puts i
    i+=1
end


#do..while loop
loop do
    puts i
    i+=1
    if i==5
        break
    end
end

        
until i>9
    puts i
    i+=1
end

#for loop

for index in 0..5
    puts index 
end

#.times loop

5.times do |index|
    puts index 
end


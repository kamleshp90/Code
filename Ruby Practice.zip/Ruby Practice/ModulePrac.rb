require_relative "ModuleTest.rb"
include Calus


puts Calus.add(55,34)

puts Calus::PI*5

puts Calus.sub(34,5)
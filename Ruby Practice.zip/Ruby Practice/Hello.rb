

#Printing
puts "Hello"
puts                #will print new line 
puts "3"+"4"        #output=34-> concatenation occurs

print "Hello"       # will not print new line after Hello
print "world"  

#Arithmatic

puts 1+5
puts 5-1
puts 4/2
puts 4%3
puts 12.0/5         #=2.4
puts 2**4           #=2 to the power 4

#Parallel variable assignment
a=10
b=20
c=30

puts a,b,c

#Swapping variable values
a=1
b=2
a,b=b,a             # swapping
puts a,b            # a=2 , b=1

#Constant
NAME="Punit"        # variable whose value not supposed to be changed is writtenn in capital letters
                    # we will get warning when we try to change the value

#String interpolation
name="Hike"
age=15
puts "Hello, my name is #{name}"
puts "My age is #{age+5}"

#user input

puts "enter name"
name=gets.chomp       # always takes input as String
age=gets.chomp.to_i   # converted to integer

#.odd? and .even? method

puts 10.odd?
puts 2.even?


#.between Method
puts 20.between?(15,25)         # =true

#float methods
puts 10.5.to_i                  #10
puts 10.5.floor                 #=10
puts 10.5.ceil                  #=11
puts 3.1456.round(2)            #=3.14
puts -3.45.abs                  #=3.45

#blocks with .times method

3.times { puts "Gloabant is awsome"}

3.times do
    puts "I work at Globant"
    puts "Gloabant is awsome"
end

3.times do |count|                      #block variable "count" starts with 0
    puts "am in #{count} loop"
    puts "Gloabant is awsome"
end

#.upto  and .downto method

5.downto(0) do |count|
    puts "am currently in #{count} block"
end

5.upto(12) do |count|
    puts "am currently in #{count} block"
end






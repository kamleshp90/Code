

def self.my_method(name)
     puts "Hello"
     name.length
end



puts Example.my_method "Pankaj"
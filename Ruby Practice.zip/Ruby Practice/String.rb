

#Equality operator 
a="Hello"
b="hello"
c="Hello"

a==b                            #false
a==c                            #true

#Concatenate string

first_name="Ruby-"
last_name="Calabash"

puts first_name+last_name                   #=Ruby-Calabash
puts first_name.prepend(last_name)          #first_name=CalabashRuby-
puts first_name.concat(last_name)           #first_name=Ruby-Calabash

#.length/size method
name="Globant"
puts name.length
puts name.size

#extract single character
book="good book"
puts book[3]                                #=d          
puts book[-3]                               #=o
puts book[50]                               #=nil

#extract multiple character
puts book[3,4]                              #=d bo
puts book[2,book.length]                    #=od book
puts book[5..book.length]                   #=book

#overrite character in string 
book[5]="c"
puts book                                   #=good cook
book[5..book.length]="mood"
puts book                                   #=good mood
book[5,4]="sound"
puts book                                   #=good sound

#case methods
puts "hello".capitalize                     #capitalize 1st letter and rest to lower case
puts "hello".upcase
puts "HELLO".downcase
puts "HEllo".swapcase                       #= heLLO


#.reverse method
puts "Hello".reverse
puts "Ruby is fun".reverse                  #=nuf si ybuR

#Bang method
word="Hello"
word.capitalize!
word.upcase!
word.downcase!
word.reverse!
word.swapcase!

#boolean  method
word="Snow white"
puts word.include?"wh"                      #true
puts word.empty?
puts word.nil?




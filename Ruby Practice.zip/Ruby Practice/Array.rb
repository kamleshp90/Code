numbers=[3,5,7,5,3,2]
numbers.push("orange")
numbers.insert(1,"Apple")   # add apple at index 1 and shift element at further indexes to rightwards
numbers.insert(2,"Banana","Cucumber")
# puts numbers
# print numbers

# puts numbers.length
# puts numbers.count(3)

numbers.empty?
numbers.nil?
numbers.first
numbers.last
numbers.pop                 # removes/returns last element from an array
numbers.pop(2)              # removes/returns last 2 elements from an array in form of array
numbers.reverse
numbers.min
numbers.max
numbers.include?(3)
numbers.index(3)            #returns index of element 3
#numbers.sort

#equality operator (==)
    # two must have same size, same elements & in the same order



    #each loop
  numbers.each do |num|
    puts num
  end


  #for loop
    for num in numbers
        puts num
    end

#.concat method

a=[1,2,3]
b=[4,5]
puts a+b
a.concat(b)

hash={1=>"green",2=>"yellow",3=>"red"}  # keeps the track of insertion order

puts hash[2]

# .each method

hash.each do |key,value|
    puts "#{key} - #{value}"
end


#.each_key method
hash.each_key do |key|
    puts key
end

#.each_value method
hash.each_value do |value|
    puts value
end


hash.keys               #returns array of keys
hash.values             #returns array of values


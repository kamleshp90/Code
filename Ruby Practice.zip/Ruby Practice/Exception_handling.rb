
a=[3,4,5,6]

begin
    puts a["index"]
    num=1/0

rescue ZeroDivisionError
    puts " ZeroDivisionError"
rescue
    puts "other error"
ensure
    puts "error rescued"
end



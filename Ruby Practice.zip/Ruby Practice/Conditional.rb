

if 5>2
    puts "condition is true"
end


color="White"

if color== "Blue"
    puts "color is blue"
elsif color=="White"
    puts "color is White"
else
    puts "it is colorless"
end


#Calculator

def add(a,b)
    a+b
end

def sub(a,b)
    a-b
end

def multiply(a,b)
    a*b
end


def calculator(a,b,operator)
    if operator=="add"
        add(a,b)
    elsif operator=="sub"
        sub(a,b)
    elsif operator=="multiply"
        multiply(a,b)
    else
        puts "wrong operator"
    end
end

puts calculator(5,7,"add")


#Switch case

def grade(marks)
    case marks
    when 80..100
        puts "A"
    when 60..79
        puts "B"
    when 40..59
        puts "c"
    else
        puts "Fail"
    end
end

puts grade(80)


#unless
pass="abcd"
unless  pass.include? "f"                   #block will execute if condition fails (in place of negation)
    puts " pass doesn't include f"
end




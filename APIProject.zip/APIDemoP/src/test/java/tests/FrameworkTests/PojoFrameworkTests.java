package tests.FrameworkTests;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import modules.FriendsHelper;
import modules.GetTestdata;
import modules.ResetPasswordHelper;
import modules.UserSignUp;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Utility.DataContainer;
import Utility.ExcelUtility;
import pojo_models.EmailSignUpWithLombok;
import pojo_models.FriendWithLombok;
import pojo_models.Login;
import pojo_models.OtpWithLombok;
import pojo_models.ResetPassword_POJO;
import pojo_models.UserInfoWithLombok;
import tests.BaseTest;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class PojoFrameworkTests extends BaseTest {
    FriendsHelper friendshelper = new FriendsHelper();

    UserSignUp userSignUp=new UserSignUp();
    UserInfoWithLombok userInfo=new UserInfoWithLombok();
    EmailSignUpWithLombok emailSignUpWithLombok=new EmailSignUpWithLombok();
    GetTestdata getTestdata=new GetTestdata();
    ResetPassword_POJO resetPassword_POJO=null;
    
    
 // Email signup functionality
 	@Test(priority=0,enabled=true,groups={"positive", "signup"} ,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
 	public void VerifyEmailFieldValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
 	{
 		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);		
// 		JsonPath js=response.getBody().jsonPath();
// 		otp=js.getString("content."OTP"});
 		SoftAssert softAssert=new SoftAssert();
 		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
 		softAssert.assertAll();


 		
 	}
 	
 	@Test(priority=1,groups={"negative", "signup"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidEmailId_FMCTest")
 	public void VerifyEmailFieldInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
 	{
 		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
 		SoftAssert softAssert=new SoftAssert();
 		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
 		softAssert.assertAll();
 	}
 	
 	@Test(priority=1,groups={"negative", "signup"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidToken_FMCTest")
 	public void VerifyEmailFieldInvalidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
 	{	
 		String inValidToken="eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlVTRVIiXSwic3ViIjoiZm1jIiwiaWF0IjoxNjY5MDk0ODI4LCJleHAiOjE2NjkxMDA4Mjh9.cWwnhBxnRfN3NrSyCxRwpi7sJ0W9VsrSRSR4gnf2303WxyHYHrHWpTJX45mcJPr6TBX4Is_1Ihr_vJU6Wi0glw";
 		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, inValidToken);
 		SoftAssert softAssert=new SoftAssert();
 		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
 		softAssert.assertAll();
 	}
    
    //verify OTP
    @Test(priority=2,groups={"positive", "OTP"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpValidOtp_FMCTest" )
    public void VerifyOtpValidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
    {
    	EmailSignUpWithLombok emailSignUpWithLombok=new EmailSignUpWithLombok();    	 	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo=userSignUp.getUserInfoPayload(payload);
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setPassword(userSignUp.getPassword());
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);	
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
    	
    }
    
    
    @Test(priority=3,groups={"negative", "OTP"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidOtp_FMCTest")
	public void VerifyOtpInvalidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo=userSignUp.getUserInfoPayload(payload);
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());   	
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,userInfo, secureToken);
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();

	}
    
    @Test(priority=3,groups={"negative", "OTP"},enabled=true , dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidEmailId_FMCTest")
	public void VerifyOtpInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo=userSignUp.getUserInfoPayload(payload);
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setPassword(userSignUp.getPassword());	
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
//		JsonPath js=response.getBody().jsonPath();
//		System.out.println(js.prettyPrint());
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=3,groups={"negative", "OTP"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPhoneNo_FMCTest")
	public void VerifyOtpInvalidPhoneNo_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo=userSignUp.getUserInfoPayload(payload);
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=3,groups={"negative", "OTP"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpWithPhoneNoFieldBlank_FMCTest")
   	public void VerifyOtpWithPhoneNoFieldBlank_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
   	{	
       	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
       	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
       	userInfo=userSignUp.getUserInfoPayload(payload);
       	userInfo.setOtp(otp.jsonPath().get("content.otp"));
       	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
       	userInfo.setPassword(userSignUp.getPassword());	
   		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
   		SoftAssert softAssert=new SoftAssert();
   		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
   		softAssert.assertAll();
   	}
    
    @Test(priority=3,groups={"negative", "OTP"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPassword_FMCTest")
	public void VerifyOtpInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo=userSignUp.getUserInfoPayload(payload);
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=3,groups={"negative", "OTP"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidName_FMCTest")
	public void VerifyOtpInvalidName_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo=userSignUp.getUserInfoPayload(payload);
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
 // login functionality
    @Test(priority=4,groups={"positive", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailValidPassword_FMCTest")
	public void VerifyLoginValidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
    	userInfo.setFull_name(userSignUp.getFullname());
    	userInfo.setPhone_number(userSignUp.getPhoneNo());    	
//    	UserInfoWithLombok.builder().email_id(emailSignUpWithLombok.getEmail_id()).full_name(userSignUp.getFullname()).otp(otp.jsonPath().get("content."OTP"})).password(payload).phone_number(payload).build(); 	
    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
    	Login login=new Login();
    	login.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	login.setPassword(userInfo.getPassword());
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//		JsonPath js=response.getBody().jsonPath();
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=5,groups={"positive", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailInvalidPassword_FMCTest")
	public void VerifyLoginValidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
    	userInfo.setFull_name(userSignUp.getFullname());
    	userInfo.setPhone_number(userSignUp.getPhoneNo());    	
//    	UserInfoWithLombok.builder().email_id(emailSignUpWithLombok.getEmail_id()).full_name(userSignUp.getFullname()).otp(otp.jsonPath().get("content."OTP"})).password(payload).phone_number(payload).build(); 	
    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
    	Login login=new Login();
    	login.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	login.setPassword(userSignUp.getPassword());
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//		JsonPath js=response.getBody().jsonPath();
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=5,groups={"positive", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInvalidEmailValidPassword_FMCTest")
	public void VerifyLoginInvalidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
    	userInfo.setFull_name(userSignUp.getFullname());
    	userInfo.setPhone_number(userSignUp.getPhoneNo());    	
//    	UserInfoWithLombok.builder().email_id(emailSignUpWithLombok.getEmail_id()).full_name(userSignUp.getFullname()).otp(otp.jsonPath().get("content."OTP"})).password(payload).phone_number(payload).build(); 	
    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
    	Login login=new Login();
    	login.setEmail_id(userSignUp.getEmailId());
    	login.setPassword(userInfo.getPassword());
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//		JsonPath js=response.getBody().jsonPath();
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=5,groups={"positive", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInalidEmailInvalidPassword_FMCTest")
	public void VerifyLoginInalidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
    	userInfo.setFull_name(userSignUp.getFullname());
    	userInfo.setPhone_number(userSignUp.getPhoneNo());    	
//    	UserInfoWithLombok.builder().email_id(emailSignUpWithLombok.getEmail_id()).full_name(userSignUp.getFullname()).otp(otp.jsonPath().get("content."OTP"})).password(payload).phone_number(payload).build(); 	
    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
    	Login login=new Login();
    	login.setEmail_id(userSignUp.getEmailId());
    	login.setPassword(userSignUp.getPassword());
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//		JsonPath js=response.getBody().jsonPath();
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
    
    @Test(priority=4,groups={"negative", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginAfterResetPasswordWithOldPassword_FMCTest")
	public void VerifyLoginAfterResetPasswordWithOldPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
    	emailSignUpWithLombok.setEmail_id(userSignUp.getEmailId());
    	//signup response
    	Response otp=(Response)userSignUp.getOTP(secureToken, "EmailSignUp", emailSignUpWithLombok);   	
    	userInfo.setOtp(otp.jsonPath().get("content.otp"));
    	userInfo.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	userInfo.setPassword(userSignUp.getPassword());	
    	userInfo.setFull_name(userSignUp.getFullname());
    	userInfo.setPhone_number(userSignUp.getPhoneNo());    	 	
    	//OTP response
    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
    	Login login=new Login();
    	login.setEmail_id(emailSignUpWithLombok.getEmail_id());
    	login.setPassword(userInfo.getPassword());
    	//login response
    	userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//		JsonPath js=response.getBody().jsonPath();
		resetPassword_POJO=new ResetPassword_POJO();
		resetPassword_POJO.setEmail_id(emailSignUpWithLombok.getEmail_id());
		resetPassword_POJO.setPassword(userSignUp.getPassword());
		//reset password response
		new ResetPasswordHelper().resetPassword(secureToken,"ResetPassword", resetPassword_POJO);		
		//login with old password response
		ResponseOptions<Response> loginResponse = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
		SoftAssert softAssert=new SoftAssert();
		softAssert.assertEquals(loginResponse.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}

	


}

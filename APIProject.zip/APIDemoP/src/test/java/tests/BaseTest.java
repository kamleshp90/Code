package tests;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Utility.RestAssuredEnginep;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import modules.UserSignUp;
import pojo_models.EmailSignUpWithLombok;
import Utility.AuthenticationToken;
import Utility.ExcelUtility;
import Utility.RestAssuredEngine;

public class BaseTest {

	public ResponseOptions<Response> response;
	RestAssuredEnginep restAssuredEngine;
	protected String secureToken = "";
	
	
    @BeforeSuite
    public void beforeSuite() throws IOException{
    	AuthenticationToken token = new AuthenticationToken();
    	secureToken = token.getAuthenticationToken();
    	restAssuredEngine = new RestAssuredEnginep(secureToken);
    	System.out.println(secureToken);
    }


    
    
    

    

}

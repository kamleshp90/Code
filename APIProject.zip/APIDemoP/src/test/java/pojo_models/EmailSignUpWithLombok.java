package pojo_models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import com.fasterxml.jackson.*;

@Getter
@Setter

public class EmailSignUpWithLombok {
	
	private   String email_id;


}

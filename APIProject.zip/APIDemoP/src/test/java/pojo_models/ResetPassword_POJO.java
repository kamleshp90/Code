package pojo_models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResetPassword_POJO {
	private String email_id;
	private String password;

}

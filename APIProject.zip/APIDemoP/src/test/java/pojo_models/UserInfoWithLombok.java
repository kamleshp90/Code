package pojo_models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserInfoWithLombok {

	private String email_id;
	private String full_name;
	private String phone_number;
	private String password;
	private String otp;
	
	
	
	
}

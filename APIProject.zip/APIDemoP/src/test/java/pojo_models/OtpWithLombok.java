package pojo_models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

@JsonIgnoreProperties(ignoreUnknown = true)
public class OtpWithLombok {

	private String email_id;
	private String  full_name;
	private String  phone_number;
	private String  password;
	private String  otp;
	
	
	
}

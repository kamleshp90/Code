package modules;

import java.util.Map;

import Utility.RestAssuredEngine;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;


public class GetPostsResource {
//	public ResponseOptions<Response> getPlaceNameDetails(String methodName, String serviceEndpoint, Map<String,String> headerMap, Map<String,String> queryParamMap, Map<String, Object> pathParamMap, String assertMessage){
//		RestAssuredEngine restAssuredEngine = new RestAssuredEngine("token");
//		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, headerMap, queryParamMap, pathParamMap, assertMessage);
//
//}
}
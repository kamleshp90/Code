package modules;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class GetTestdata {
	
	public Object getValue(String key) throws IOException
	{
		Properties prop=new Properties();
		FileReader reader=new FileReader("/Users/kamlesh.patle/Downloads/APIDemoP/src/test/resources/Test_Data.properties");
		prop.load(reader);
		return prop.getProperty(key);
	}
	
	public void setValue(String key, String value) throws IOException
	{
		Properties prop=new Properties();
		
//		
//		if(prop.containsKey((Object)key) )
//		{
//			prop.replace(key, prop.get(key), value);
//		}
//		else
//		{
//			prop.setProperty(key, value);
//		}
		prop.replace(key, prop.get(key), value);
		
		FileOutputStream file=new FileOutputStream("/Users/kamlesh.patle/Downloads/APIDemoP/src/test/resources/Test_Data.properties" , true);		
		prop.store(file, "");

	}

}

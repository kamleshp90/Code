package modules;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Utility.ExcelUtility;
import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.Login;

public class LoginHelper {
	

	public ResponseOptions<Response> loginUser(String token, String module ,Object payload)
	{
		ArrayList<String> list=new ArrayList<String>(ExcelUtility.getAPIParams(module));
		RestAssuredEnginep restAssuredEnginep = new RestAssuredEnginep(token);
		return restAssuredEnginep.executeWithPathParamsAndBody(list.get(2), list.get(0)+list.get(1),payload);
		
	}
	
	public Login getCredentialsAsObject(String payload) 
	{
		try {
			ObjectMapper mapper=new ObjectMapper();
			Login login =mapper.readValue(payload, Login.class);
			return login;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}

}

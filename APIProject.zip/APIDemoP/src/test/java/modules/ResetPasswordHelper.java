package modules;

import java.util.ArrayList;

import Utility.ExcelUtility;
import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class ResetPasswordHelper {
	
	
	public ResponseOptions<Response> resetPassword(String token, String module ,Object payload)
	{
		ArrayList<String> list=new ArrayList<String>(ExcelUtility.getAPIParams(module));
		RestAssuredEnginep restAssuredEnginep = new RestAssuredEnginep(token);
		return restAssuredEnginep.executeWithPathParamsAndBody(list.get(2), list.get(0)+list.get(1),payload);
		
	}
	
	public ResponseOptions<Response> resetPassword(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}

}

package modules;

import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.EmailSignUpWithLombok;
import pojo_models.UserInfoWithLombok;
import Utility.ExcelUtility;
import Utility.RestAssuredEngine;

public class UserSignUp {
	
	
//	UserSignUp userSignUp=new UserSignUp();
	
	public ResponseOptions<Response> verifyEmailId(String methodName, String serviceEndpoint, String payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyEmailId(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyValidOtp(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	public UserInfoWithLombok getUserInfoPayload(String payload)
	{
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			UserInfoWithLombok userInfo = mapper.readValue(payload, UserInfoWithLombok.class);
			return userInfo;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	
	public String getEmailId()
	{
			Faker faker=new Faker();
			return faker.internet().emailAddress();
	}
	
	public String getPayloadAsString(Object email)
	{
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(email);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void setUserDetails()
	{
		
	}
	
	public String getPassword()
	{
		Faker faker=new Faker();
		return faker.internet().password();
	}
	
	public String getFullname()
	{
		Faker faker=new Faker();
		return faker.name().fullName();
	}
	
	public String getPhoneNo()
	{
		Faker faker=new Faker();
		return faker.phoneNumber().cellPhone();
	}
	
	public ResponseOptions<Response> getOTP(String token, String module ,Object payload)
	{
		ArrayList<String> list=new ArrayList<String>(ExcelUtility.getAPIParams(module));
		RestAssuredEnginep restAssuredEnginep = new RestAssuredEnginep(token);
		return restAssuredEnginep.executeWithPathParamsAndBody(list.get(2), list.get(0)+list.get(1),payload);
		
	}
	
	public ResponseOptions<Response> addOTP(String token, String module ,Object payload)
	{
		ArrayList<String> list=new ArrayList<String>(ExcelUtility.getAPIParams(module));
		RestAssuredEnginep restAssuredEnginep = new RestAssuredEnginep(token);
		return restAssuredEnginep.executeWithPathParamsAndBody(list.get(2), list.get(0)+list.get(1),payload);
		
	}



}

package modules;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class UserDelete {
	
	
	public ResponseOptions<Response> deleteUser(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}

}

package Utility;

import java.util.ArrayList;
import java.util.List;

//import pojo_models.EmailSignUpWithLombok;

public class DataContainer {
	
	private DataContainer() {};
	
	private static ArrayList<String> signedUpEmailList = new ArrayList<String>();

	public static String getSignedUpEmailList() {
		return DataContainer.signedUpEmailList.get(0);
	}

	public static void setSignedUpEmailList(String signedUpEmail) {
		DataContainer.signedUpEmailList.add(0, signedUpEmail);;
	}
	
	

}
